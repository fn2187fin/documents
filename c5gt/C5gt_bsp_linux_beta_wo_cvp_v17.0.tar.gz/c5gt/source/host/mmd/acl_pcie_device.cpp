// (C) 1992-2017 Intel Corporation.                            
// Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words    
// and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.  
// and/or other countries. Other marks and brands may be claimed as the property  
// of others. See Trademarks on intel.com for full list of Intel trademarks or    
// the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera) 
// Your use of Intel Corporation's design tools, logic functions and other        
// software and tools, and its AMPP partner logic functions, and any output       
// files any of the foregoing (including device programming or simulation         
// files), and any associated documentation or information are expressly subject  
// to the terms and conditions of the Altera Program License Subscription         
// Agreement, Intel MegaCore Function License Agreement, or other applicable      
// license agreement, including, without limitation, that your use is for the     
// sole purpose of programming logic devices manufactured by Intel and sold by    
// Intel or its authorized distributors.  Please refer to the applicable          
// agreement for further details.                                                 


/* ===- acl_pcie_device.cpp  ------------------------------------------ C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file implements the class to handle operations on a single device.         */
/* The declaration of the class lives in the acl_pcie_device.h                     */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */


#if defined(WINDOWS)
#define NOMINMAX
#endif   // WINDOWS

// common and its own header files
#include "acl_pcie.h"
#include "acl_pcie_device.h"

// other header files inside MMD driver
#include "acl_pcie_config.h"
#include "acl_pcie_dma.h"
#include "acl_pcie_mm_io.h"
#include "acl_pcie_debug.h"
#include "acl_pcie_flash.h"
#include "acl_pcie_quickudp.h"
#include "pkg_editor.h"

// other standard header files
#include <sstream>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <limits>

#if defined(LINUX)
#  include <sys/types.h>
#  include <sys/stat.h>
#  include <sys/time.h>
#  include <sys/mman.h>
#  include <fcntl.h>
#  include <signal.h>
#  include <unistd.h>
#endif   // LINUX



static int num_open_devices = 0;

#if defined(WINDOWS)
WDC_DEVICE_HANDLE open_device_windows(ACL_PCIE_DEVICE_DESCRIPTION *info, int dev_num);

// Interrupt service routine for all interrupts on the PCIe interrupt line
// PCIe interrupts in Windows XP are level-based.  The KMD is responsible for
// masking off the interrupt until this routine can service the request at
// user-mode priority.
extern void pcie_interrupt_handler( void* data );
#endif   // WINDOWS
#if defined(LINUX)
WDC_DEVICE_HANDLE open_device_linux(ACL_PCIE_DEVICE_DESCRIPTION *info, int dev_num);
#endif   // LINUX



ACL_PCIE_DEVICE::ACL_PCIE_DEVICE( int dev_num, const char *name, int handle ) :
   kernel_interrupt(NULL),
   kernel_interrupt_user_data(NULL),
   event_update(NULL),
   event_update_user_data(NULL),
   m_io( NULL ),
   m_dma( NULL ),
   m_flash( NULL ),
   m_config( NULL ),
   m_quickudp0( NULL ),
   m_quickudp1( NULL ),
   m_handle( -1 ),
   m_device( INVALID_DEVICE ),
#if ACL_USE_DMA==1
   m_use_dma_for_big_transfers(true),
#else
   m_use_dma_for_big_transfers(false),
#endif
   m_mmd_irq_handler_enable( false ),
   m_initialized( false ),
   m_being_programmed( false )
{
   ACL_PCIE_ASSERT(name != NULL, "passed in an empty name pointer when creating device object.\n");

   int status = 0;

   // Set debug level from the environment variable ACL_PCIE_DEBUG
   // Determine if warning messages should be disabled depends on ACL_PCIE_WARNING
   if (num_open_devices == 0) {  
      set_mmd_debug();
      set_mmd_warn_msg();
   }

   strncpy( m_name, name, (MAX_NAME_LENGTH-1) );
   m_name[(MAX_NAME_LENGTH-1)] = '\0';

   m_handle         = handle;
   m_info.vendor_id = ACL_PCI_ALTERA_VENDOR_ID;
   m_info.device_id = 0;   // search for all device id   

#if defined(WINDOWS)
   m_device = open_device_windows(&m_info, dev_num);
#endif   // WINDOWS
#if defined(LINUX)
   m_device = open_device_linux  (&m_info, dev_num);
#endif   // LINUX

   // Return to caller if this is simply an invalid device.
   if (m_device == INVALID_DEVICE) {  return;  }
   
   // Initialize device IO and CONFIG objects
   m_io     = new ACL_PCIE_MM_IO_MGR( m_device );
   m_config = new ACL_PCIE_CONFIG   ( m_device );

   // Set the segment ID to 0 first forcing cached "segment" to all 1s
   m_segment=(size_t)~0;
   if ( this->set_segment( 0x0 ) ) {  return;  }

   // performance basic I/O tests
   if ( this->version_id_test() ) {   return;   }
   if ( this->wait_for_uniphy() ) {   return;   }

   // Create interface to FPGA configuration Flash.  Allows config
   // bitstream to be replaced so that FPGA periphery can be changed.
   m_flash = new ACL_PCIE_FLASH( m_device, m_io, this );

   // Get PCIE information 
   unsigned int pcie_gen, pcie_num_lanes; 
   char pcie_slot_info_str[128] = {0}; 

   status = m_config->query_pcie_info(&pcie_gen, &pcie_num_lanes, pcie_slot_info_str); 
   ACL_PCIE_ERROR_IF(status, return,  
      "[%s] fail to query PCIe related information.\n", m_name);    
   sprintf(m_info.pcie_info_str, "dev_id = %04X, bus:slot.func = %s, at Gen %u with %u lanes",  
      m_info.device_id, pcie_slot_info_str, pcie_gen, pcie_num_lanes); 

   // Initialize the DMA object and enable interrupts on the DMA controller
   m_dma    = new ACL_PCIE_DMA( m_device, m_io, this );
   status = m_io->dma->write32( DMA_CSR_CONTROL, ACL_PCIE_GET_BIT(DMA_CTRL_IRQ_ENABLE) );
   ACL_PCIE_ERROR_IF(status, return, 
      "[%s] fail to enable interrupts on the DMA controller.\n", m_name);

   if ( this->enable_interrupts() ) {  return;  }

   // Done!
   m_initialized = true;
   ACL_PCIE_DEBUG_MSG(":: [%s] successfully initialized (device id: %x).\n", m_name, m_info.device_id);
   ACL_PCIE_DEBUG_MSG("::           Using DMA for big transfers? %s\n", 
            ( m_use_dma_for_big_transfers ? "yes" : "no" ) );

   // Dump Flash bootsector if requested through debug environment variable
   if (ACL_PCIE_DEBUG_FLASH_DUMP_BOOT_SECTOR) {
     m_flash->dump_boot_loader_status();
     m_flash->flash_debug_dump_boot_sector();
   }
}

ACL_PCIE_DEVICE::~ACL_PCIE_DEVICE()
{
   int status = this->disable_interrupts();
   ACL_PCIE_ERROR_IF(status, /* do nothing */ , 
      "[%s] fail disable interrupt in device destructor.\n", m_name);

   if(m_dma)       { delete m_dma;    m_dma = NULL;    }
   if(m_config)    { delete m_config; m_config = NULL; }
   if(m_io)        { delete m_io;     m_io = NULL;     }
   if(m_flash)     { delete m_flash;  m_flash = NULL;  }
   if(m_quickudp0) { delete m_quickudp0;  m_quickudp0 = NULL;  }
   if(m_quickudp1) { delete m_quickudp1;  m_quickudp1 = NULL;  }

   if(is_valid()) { 
      --num_open_devices;
#if defined(WINDOWS)
      DWORD WD_status = WDC_PciDeviceClose(m_device);
      ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, return, 
         "[%s] failed to close the device handle.\n", m_name);

      if (num_open_devices == 0) {
         WD_status = WDC_DriverClose();
         ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, return, 
            "failed to close the WinDriver library.\n" );
      }
#endif   // WINDOWS
#if defined(LINUX)
      close (m_device);
#endif   // LINUX
   }
}



#if defined(WINDOWS)
WDC_DEVICE_HANDLE open_device_windows(ACL_PCIE_DEVICE_DESCRIPTION *info, int dev_num)
{
   DWORD WD_status;
   WDC_PCI_SCAN_RESULT pci_scan_result;
   WD_PCI_CARD_INFO    device_info;
   WDC_DEVICE_HANDLE   device = INVALID_DEVICE;

   // Only open the WDC library handle once
   if (num_open_devices == 0) {
      const char *license = JUNGO_LICENSE;
      WD_status = WDC_DriverOpen( WDC_DRV_OPEN_DEFAULT, license );
      ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, return NULL, 
         "can't load the WinDriver library.\n" );
   }

   // Scan for our PCIe device
   WD_status = WDC_PciScanDevices( info->vendor_id, info->device_id, &pci_scan_result );
   ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, goto fail, 
      "failed to scan for the PCI device.\n");

   if( (unsigned int)dev_num >= pci_scan_result.dwNumDevices || dev_num < 0) {
      ACL_PCIE_DEBUG_MSG(":: [acl%d] Device not found\n", dev_num);
      goto fail;
   }

   // Query the device information
   device_info.pciSlot = pci_scan_result.deviceSlot[dev_num];
   WD_status = WDC_PciGetDeviceInfo( &device_info );
   ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, goto fail, 
      "[acl%d] failed to query device info.\n", dev_num);

   // Save the device id for the selected board
   info->device_id = pci_scan_result.deviceId[dev_num].dwDeviceId;

   // Open a device handle
   WD_status = WDC_PciDeviceOpen( &device, &device_info, NULL, NULL, NULL, NULL );
   ACL_PCIE_ERROR_IF( WD_status != WD_STATUS_SUCCESS, goto fail, 
      "[acl%d] failed to open the device.\n", dev_num);

   ++num_open_devices;
   return device;

fail:
   // get here after opening the driver and then failing something else.
   if (num_open_devices == 0) WDC_DriverClose();
   return INVALID_DEVICE;
}
#endif // WINDOWS
#if defined(LINUX)
WDC_DEVICE_HANDLE open_device_linux(ACL_PCIE_DEVICE_DESCRIPTION *info, int dev_num)
{
   char buf[128] = {0};
   char expected_ver_string[128] = {0};

   sprintf(buf,"/dev/acl%d", dev_num);
   ssize_t device = open (buf, O_RDWR);

   // Return INVALID_DEVICE when the device is not available
   if (device == -1) {
      return INVALID_DEVICE; 
   }

   // Make sure the Linux kernel driver is recent
   struct acl_cmd driver_cmd = { ACLPCI_CMD_BAR, ACLPCI_CMD_GET_DRIVER_VERSION,
                              NULL, buf, 0 };
   read (device, &driver_cmd, 0);

   sprintf(expected_ver_string, "%s.%s", ACL_BOARD_PKG_NAME, KERNEL_DRIVER_VERSION_EXPECTED);
   ACL_PCIE_ERROR_IF( strstr(buf, expected_ver_string) != buf, return INVALID_DEVICE,
      "Kernel driver version is %s. Expected version %s\n", buf, expected_ver_string );

   // Save the device id for the selected board
   driver_cmd.bar_id         = ACLPCI_CMD_BAR;
   driver_cmd.command        = ACLPCI_CMD_GET_PCI_DEV_ID;
   driver_cmd.device_addr    = NULL;
   driver_cmd.user_addr      = &info->device_id;
   driver_cmd.size           = sizeof(info->device_id);
   read (device, &driver_cmd, sizeof(driver_cmd));

   // Set the FD_CLOEXEC flag for the file handle to disable the child to 
   // inherit this file handle. So the jtagd will not hold the file handle
   // of the device and keep sending bogus interrupts after we call quartus_pgm.
   int oldflags = fcntl( device, F_GETFD, 0);
   fcntl( device, F_SETFD, oldflags | FD_CLOEXEC );

   ++num_open_devices;
   return device;
}

#endif   // LINUX



// Perform operations required when an interrupt is received for this device
void ACL_PCIE_DEVICE::service_interrupt(unsigned int irq_type_flag)
{
   unsigned int kernel_update = 0;
   unsigned int dma_update    = 0;

   int status = this->get_interrupt_type(&kernel_update, &dma_update, irq_type_flag);
   ACL_PCIE_ERROR_IF(status, return, "[%s] fail to service the interrupt.\n", m_name);

   ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_IRQ,
      ":: [%s] Irq service routine called, kernel_update=%d, dma_update=%d \n", 
      m_name, kernel_update, dma_update);

   if (kernel_update && kernel_interrupt != NULL) {
      // A kernel-status interrupt - update the status of running kernels
      ACL_PCIE_ASSERT(kernel_interrupt, 
         "[%s] received kernel interrupt before the handler is installed.\n", m_name);
      kernel_interrupt(m_handle, kernel_interrupt_user_data);
   } else if (dma_update) {
      // A DMA-status interrupt - let the DMA object handle this
      m_dma->service_interrupt();
   }

   // Unmask the kernel_irq to enable the interrupt again.
   if(m_mmd_irq_handler_enable){
      status = this->unmask_irqs();   
   } else if(kernel_update) {
      status = this->unmask_kernel_irq();  
   }
   ACL_PCIE_ERROR_IF(status, return, "[%s] fail to service the interrupt.\n", m_name);   

   return;
}



// Enable all interrupts (DMA and Kernel)
// Won't enable kernel irq unless kernel interrupt callback has been initialized
// Return 0 on success
int ACL_PCIE_DEVICE::unmask_irqs()
{
   int status;
   if ( kernel_interrupt == NULL ) {
      status = m_io->pcie_cra->write32( PCIE_CRA_IRQ_ENABLE, 
          ACL_PCIE_GET_BIT(ACL_PCIE_DMA_IRQ_VEC));
   } else {
      status = m_io->pcie_cra->write32( PCIE_CRA_IRQ_ENABLE, 
          ACL_PCIE_GET_BIT(ACL_PCIE_KERNEL_IRQ_VEC) | ACL_PCIE_GET_BIT(ACL_PCIE_DMA_IRQ_VEC));
   }
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] fail to unmask all interrupts.\n", m_name);

   return 0; // success
}

// Enable the kernel interrupt only
// Return 0 on success
int ACL_PCIE_DEVICE::unmask_kernel_irq()
{
   int status = 0;
   UINT32 val = 0;

   status |= m_io->pcie_cra->read32 ( PCIE_CRA_IRQ_ENABLE, &val);
   val    |= ACL_PCIE_GET_BIT(ACL_PCIE_KERNEL_IRQ_VEC);
   status |= m_io->pcie_cra->write32( PCIE_CRA_IRQ_ENABLE, val);

   ACL_PCIE_ERROR_IF(status, return -1, "[%s] fail to unmask the kernel interrupts.\n", m_name);
   
   return 0; // success
}

// Disable the interrupt
// Return 0 on success
int ACL_PCIE_DEVICE::disable_interrupts()
{
   int status;

   if(m_mmd_irq_handler_enable) {
      ACL_PCIE_DEBUG_MSG(":: [%s] Disabling interrupts.\n", m_name);

      status = m_io->pcie_cra->write32( PCIE_CRA_IRQ_ENABLE, 0 );
      ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to disable pcie interrupt.\n", m_name);

#if defined(WINDOWS)
      // Disable KMD interrupt handling for Windows
      DWORD WD_status = WDC_IntDisable(m_device);
      ACL_PCIE_ERROR_IF(WD_status != WD_STATUS_SUCCESS, return -1, "[%s] failed to disable interrupt in KMD.\n", m_name);
#endif   // WINDOWS
      m_mmd_irq_handler_enable = false;
   }
   
   return 0; // success
}

#if defined(WINDOWS)

// Enable PCI express interrupts.  Set up the KMD to mask the interrupt enable bit when
//    an interrupt is received to prevent the level-sensitive interrupt from immediately
//    firing again.
// Return 0 on success
int ACL_PCIE_DEVICE::enable_interrupts()
{
   int status;
   WDC_DEVICE *pDevice;

   ACL_PCIE_DEBUG_MSG(":: [%s] Enabling PCIe interrupts.\n", m_name);

   // Mask off hardware interrupts before enabling them
   status = m_io->pcie_cra->write32( PCIE_CRA_IRQ_ENABLE, 0 );
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to mask off all interrupts before enabling them.\n", m_name);

   // The device handle is actually just a pointer to the device object
   pDevice = (WDC_DEVICE*)(m_device);

   // Zero off the IRQ acknowledgement commands
   memset( irq_ack_cmds, 0, NUM_ACK_CMDS * sizeof(WD_TRANSFER) );

   // Set up the list of commands to mask out the interrupt until it is properly processed
      // CMD0 - Read the IRQ status register
   irq_ack_cmds[0].cmdTrans = RM_DWORD;
   irq_ack_cmds[0].dwPort = pDevice->pAddrDesc[m_io->pcie_cra->bar_id()].kptAddr +
                            m_io->pcie_cra->convert_to_bar_addr( PCIE_CRA_IRQ_STATUS );
   irq_ack_cmds[0].dwBytes = 0;
   irq_ack_cmds[0].fAutoinc = 0;
   irq_ack_cmds[0].dwOptions = 0;
   irq_ack_cmds[0].Data.Dword = 0;
      // CMD1 - Verify that the RxmIRQ bit is enabled (i.e. we own this IRQ)
   irq_ack_cmds[1].cmdTrans = CMD_MASK;
   irq_ack_cmds[1].dwPort = 0;
   irq_ack_cmds[1].dwBytes = 0;
   irq_ack_cmds[1].fAutoinc = 0;
   irq_ack_cmds[1].dwOptions = 0;
   irq_ack_cmds[1].Data.Dword = ACL_PCIE_GET_BIT(ACL_PCIE_KERNEL_IRQ_VEC) | ACL_PCIE_GET_BIT(ACL_PCIE_DMA_IRQ_VEC);
      // CMD2 - Mask off RxmIRQ requests until we've processed this interrupt
   irq_ack_cmds[2].cmdTrans = WM_DWORD;
   irq_ack_cmds[2].dwPort = pDevice->pAddrDesc[m_io->pcie_cra->bar_id()].kptAddr +
                            m_io->pcie_cra->convert_to_bar_addr( PCIE_CRA_IRQ_ENABLE );
   irq_ack_cmds[2].dwBytes = 0;
   irq_ack_cmds[2].fAutoinc = 0;
   irq_ack_cmds[2].dwOptions = 0;
   irq_ack_cmds[2].Data.Dword = 0;

   ACL_PCIE_DEBUG_MSG(":: [%s] Interrupt handler:\n", m_name);
   ACL_PCIE_DEBUG_MSG("::             KMD Bar%d addr 0x%p\n", 
      m_io->pcie_cra->bar_id(), pDevice->pAddrDesc[m_io->pcie_cra->bar_id()].kptAddr);
   ACL_PCIE_DEBUG_MSG("::             Read  <- 0x%x\n", irq_ack_cmds[0].dwPort);
   ACL_PCIE_DEBUG_MSG("::             Mask     0x%x\n", irq_ack_cmds[1].Data.Dword);
   ACL_PCIE_DEBUG_MSG("::             Write -> 0x%x\n", irq_ack_cmds[2].dwPort);

   // Enable interrupts in the KMD
   DWORD WD_status = WDC_IntEnable( 
            m_device,                  // The device handle
            irq_ack_cmds,              // Array of commands to execute in the KMD
            NUM_ACK_CMDS,              // Size of the above array
            0,                         // Options
            &pcie_interrupt_handler,   // Function pointer to the ISR
            static_cast<void*>(this),  // Custom ISR arguments
            FALSE                      // Custom kernal-mode ISR acceleration
         );
   ACL_PCIE_ERROR_IF(WD_status != WD_STATUS_SUCCESS, return -1, "[%s] failed to enable interrupts in the KMD.\n", m_name);

   status = this->unmask_irqs();
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to enable interrupts.\n", m_name);

   m_mmd_irq_handler_enable = true;
   return 0; // success
}

// Use irq status to determine type of interrupt
// Result is returned in kernel_update/dma_update arguments.
// Return 0 on success
int ACL_PCIE_DEVICE::get_interrupt_type (unsigned int *kernel_update, unsigned int *dma_update, unsigned int irq_type_flag)
{
   UINT32 irq_status;
   int    status;

   status = m_io->pcie_cra->read32( PCIE_CRA_IRQ_STATUS, &irq_status );
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] fail to interrupt type.\n", m_name);

   *kernel_update = ACL_PCIE_READ_BIT( irq_status, ACL_PCIE_KERNEL_IRQ_VEC );
   *dma_update    = ACL_PCIE_READ_BIT( irq_status, ACL_PCIE_DMA_IRQ_VEC);
   return 0; // success
}

#endif   // WINDOWS
#if defined(LINUX)

// For Linux, it will set-up a signal handler for signals for kernel driver
// Return 0 on success
int ACL_PCIE_DEVICE::enable_interrupts()
{
   int status;
   ACL_PCIE_DEBUG_MSG(":: [%s] Enabling PCIe interrupts on Linux (via signals).\n", m_name);

   // All interrupt controls are in the kernel driver.
   m_mmd_irq_handler_enable = false;

   // Set "our" device id (the handle id received from acl_pcie.cpp) to correspond to 
   // the device managed by the driver. Will get back this id 
   // with signal from the driver. Will allow us to differentiate
   // the source of kernel-done signals with multiple boards.

   // the last bit is reserved as a flag for DMA completion
   int result = m_handle << 1;
   struct acl_cmd read_cmd = { ACLPCI_CMD_BAR, 
                                 ACLPCI_CMD_SET_SIGNAL_PAYLOAD, 
                                 NULL, 
                                 &result };
   status = write (m_device, &read_cmd, sizeof(result));
   ACL_PCIE_ERROR_IF( status, return -1, "[%s] failed to enable interrupts.\n", m_name );

   return 0; // success
}

// Determine the interrupt type using the irq_type_flag
// Return 0 on success
int ACL_PCIE_DEVICE::get_interrupt_type (unsigned int *kernel_update, unsigned int *dma_update, unsigned int irq_type_flag)
{
   // For Linux, the interrupt type is mutually exclusive
   *kernel_update = irq_type_flag ? 0: 1;
   *dma_update = 1 - *kernel_update;

   return 0; // success
}

#endif // LINUX



// Called by the host program when there are spare cycles
int ACL_PCIE_DEVICE::yield()
{
   // Give the DMA object a chance to crunch any pending data
   return m_dma->yield();
}



// Set kernel interrupt and event update callbacks
// return 0 on success
int ACL_PCIE_DEVICE::set_kernel_interrupt(aocl_mmd_interrupt_handler_fn fn, void * user_data) 
{
   int status;

   kernel_interrupt = fn;
   kernel_interrupt_user_data = user_data;
 
   if ( m_device != INVALID_DEVICE ) {
      status = this->unmask_kernel_irq();
      ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to set kernel interrupt callback funciton.\n", m_name);
   }
   
   return 0; // success
}

int ACL_PCIE_DEVICE::set_status_handler(aocl_mmd_status_handler_fn fn, void * user_data)
{
   event_update = fn;
   event_update_user_data = user_data;
   
   return 0; // success
}

// The callback function set by "set_status_handler"
// It's used to notify/update the host whenever an event is finished
void ACL_PCIE_DEVICE::event_update_fn(aocl_mmd_op_t op, int status)
{
   ACL_PCIE_ASSERT(event_update, "[%s] event_update is called with a empty update function pointer.\n", m_name);

   ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_OP,":: [%s] Update for event e=%p.\n", m_name, op);
   event_update(m_handle, event_update_user_data, op, status);
}



// Memory I/O
// return 0 on success
int ACL_PCIE_DEVICE::write_block( aocl_mmd_op_t e, aocl_mmd_interface_t mmd_interface, void *host_addr, size_t dev_addr, size_t size )
{
   ACL_PCIE_ASSERT(event_update, "[%s] event_update callback function is not provided.\n", m_name);
   int status = -1; // assume failure

   switch(mmd_interface)
   {
      case AOCL_MMD_KERNEL:
         status = m_io->kernel_if->write_block( dev_addr, size, host_addr );
         break;
      case AOCL_MMD_MEMORY:
         status = read_write_block (e, host_addr, dev_addr, size, false /*writing*/);
         break;
      case AOCL_MMD_PLL:
         status = m_io->pll->write_block( dev_addr, size, host_addr );
         break;
      default:
         ACL_PCIE_ASSERT(0, "[%s] unknown MMD interface.\n", m_name);
   }
   
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to write block.\n", m_name);
   
   return 0; // success
}

int ACL_PCIE_DEVICE::read_block( aocl_mmd_op_t e, aocl_mmd_interface_t mmd_interface, void *host_addr, size_t dev_addr, size_t size )
{
   ACL_PCIE_ASSERT(event_update, "[%s] event_update callback function is not provided.\n", m_name);
   int status = -1; // assume failure

   switch(mmd_interface)
   {
      case AOCL_MMD_KERNEL:
         status = m_io->kernel_if->read_block( dev_addr, size, host_addr );
         break;
      case AOCL_MMD_MEMORY:
         status = read_write_block (e, host_addr, dev_addr, size, true /*reading*/);
         break;
      case AOCL_MMD_PLL:
         status = m_io->pll->read_block( dev_addr, size, host_addr );
         break;
      default:
         ACL_PCIE_ASSERT(0, "[%s] unknown MMD interface.\n", m_name);
   }
   
   ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to read block.\n", m_name);
   
   return 0; // success
}

// Copy a block between two locations in device memory
// return 0 on success
int ACL_PCIE_DEVICE::copy_block( aocl_mmd_op_t e, aocl_mmd_interface_t mmd_interface, size_t src, size_t dst, size_t size )
{
   ACL_PCIE_ASSERT(event_update, "[%s] event_update callback function is not provided.\n", m_name);
   ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_OP,
      ":: [%s] Copying " SIZE_FMT_U " bytes data from 0x" SIZE_FMT_X " (device) to 0x" SIZE_FMT_X " (device), with e=%p\n", 
      m_name, size, src, dst, e);

#define BLOCK_SIZE (8*1024*1024)
#if defined(WINDOWS)
   __declspec(align(128)) static unsigned char data[BLOCK_SIZE];
#endif   // WINDOWS
#if defined(LINUX)
   static unsigned char data[BLOCK_SIZE] __attribute__((aligned(128)));
#endif   // LINUX

   do {
      size_t transfer_size = (size > BLOCK_SIZE) ? BLOCK_SIZE : size;
      read_block ( NULL /* blocking read  */, mmd_interface, data, src, transfer_size );
      write_block( NULL /* blocking write */, mmd_interface, data, dst, transfer_size );

      src  += transfer_size;
      dst  += transfer_size;
      size -= transfer_size;
   } while (size > 0);

   if (e)  { this->event_update_fn(e, 0); }

   return 0; // success
}



// Read or Write a block of data to device memory. 
// Use either DMA or directly read/write through BAR
// Return 0 on success
int ACL_PCIE_DEVICE::read_write_block( aocl_mmd_op_t e, void *host_addr, size_t dev_addr, size_t size, bool reading )
{
   const uintptr_t uintptr_host = reinterpret_cast<uintptr_t>(host_addr);

   int    status   = 0;
   size_t dma_size = 0;
   
   if(reading){
      ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_OP,
         ":: [%s] Reading " SIZE_FMT_U " bytes data from 0x" SIZE_FMT_X " (device) to %p (host), with e=%p\n", 
         m_name, size, dev_addr, host_addr, e);
   } else {
      ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_OP,
         ":: [%s] Writing " SIZE_FMT_U " bytes data from %p (host) to 0x" SIZE_FMT_X " (device), with e=%p\n", 
         m_name, size, host_addr, dev_addr, e);
   }

   // Return immediately if size is zero
   if( size == 0 ) {
      if (e)  { this->event_update_fn(e, 0); }
      return 0;
   }

   bool aligned = ((uintptr_host & DMA_ALIGNMENT_BYTE_MASK) | (dev_addr & DMA_ALIGNMENT_BYTE_MASK)) == 0;
   if ( m_use_dma_for_big_transfers && aligned && (size >= 1024) )
   {
      // DMA transfers must END at aligned boundary.
      // If that's not the case, use DMA up to such boundary, and regular
      // read/write for the remaining part.
      dma_size = size - (size & DMA_ALIGNMENT_BYTE_MASK);
   } else if( m_use_dma_for_big_transfers && (size >= 1024) ) {
      ACL_PCIE_WARN_MSG("[%s] NOT using DMA to transfer " SIZE_FMT_U " bytes from %s to %s because of lack of alignment\n" 
         "**                 host ptr (%p) and/or dev offset (0x" SIZE_FMT_X ") is not aligned to %u bytes\n", 
         m_name, size, (reading ? "device":"host"), (reading ? "host":"device"), host_addr, dev_addr, DMA_ALIGNMENT_BYTES);
   }

   // Perform read/write through BAR if the data is not fit for DMA or if there is remaining part from DMA
   if ( dma_size < size ) {
      void * host_addr_new = reinterpret_cast<void *>(uintptr_host + dma_size);
      size_t dev_addr_new  = dev_addr + dma_size;
      size_t remain_size   = size - dma_size;

      ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_OP,
         ":: [%s] Perform read/write through BAR for remaining " SIZE_FMT_U " bytes (out of " SIZE_FMT_U " bytes)\n", 
         m_name, remain_size, size); 

      status = read_write_block_bar( host_addr_new, dev_addr_new, remain_size, reading );
      ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to perform read/write through BAR.\n", m_name);
   }

   if ( dma_size != 0 ) {
      m_dma->read_write (host_addr, dev_addr, dma_size, e, reading);

      // Block if event is NULL
      if (e == NULL) {  m_dma->stall_until_idle();  }
   } else {
      if (e != NULL) {  this->event_update_fn(e, 0);  }
   }

   return 0; // success
}

// Read or Write a block of data to device memory through BAR
// Return 0 on success
int ACL_PCIE_DEVICE::read_write_block_bar( void *host_addr, size_t dev_addr, size_t size, bool reading )
{
   void * cur_host_addr = host_addr;
   size_t cur_dev_addr  = dev_addr;
   size_t bytes_transfered = 0;

   for (bytes_transfered=0; bytes_transfered<size; )
   {
      // decide the size to transfer for current iteration
      size_t cur_size = ACL_PCIE_MEMWINDOW_SIZE - ( cur_dev_addr%ACL_PCIE_MEMWINDOW_SIZE );
      if (bytes_transfered + cur_size >= size) {
         cur_size = size - bytes_transfered;
      }

      // set the proper window segment
      set_segment( cur_dev_addr );
      size_t window_rel_ptr_start = cur_dev_addr % ACL_PCIE_MEMWINDOW_SIZE;
      size_t window_rel_ptr       = window_rel_ptr_start;

      // A simple blocking read
      // The address should be in the global memory range, we assume
      // any offsets are already accounted for in the offset
      ACL_PCIE_ASSERT( window_rel_ptr + cur_size <= ACL_PCIE_MEMWINDOW_SIZE, 
         "[%s] trying to access out of the range of the memory window.\n", m_name);

      // Workaround a bug in Jungo driver.
      // First, transfer the non 8 bytes data at the front, one byte at a time
      // Then, transfer multiple of 8 bytes (size of size_t) using read/write_block
      // At the end, transfer the remaining bytes, one byte at a time
      size_t dev_odd_start = std::min (sizeof(size_t) - window_rel_ptr % sizeof(size_t), cur_size);
      if (dev_odd_start != sizeof(size_t)) {
         read_write_small_size( cur_host_addr, window_rel_ptr, dev_odd_start, reading );
         incr_ptrs (&cur_host_addr, &window_rel_ptr, &bytes_transfered, dev_odd_start );
         cur_size -= dev_odd_start;
      }

      size_t tail_size  = cur_size % sizeof(size_t);
      size_t size_mul_8 = cur_size - tail_size;

      if (size_mul_8 != 0) {
         if ( reading ) {
            m_io->mem->read_block ( window_rel_ptr, size_mul_8, cur_host_addr );
         } else {
            m_io->mem->write_block( window_rel_ptr, size_mul_8, cur_host_addr );
         }
         incr_ptrs (&cur_host_addr, &window_rel_ptr, &bytes_transfered, size_mul_8);
      }

      if (tail_size != 0) {
         read_write_small_size( cur_host_addr, window_rel_ptr, tail_size, reading );
         incr_ptrs (&cur_host_addr, &window_rel_ptr, &bytes_transfered, tail_size );
         cur_size -= tail_size;
      }

      // increase the current device address to be transferred
      cur_dev_addr += (window_rel_ptr - window_rel_ptr_start);
   }

   return 0; // success
}

// Read or Write a small size of data to device memory, one byte at a time
// Return 0 on success
int ACL_PCIE_DEVICE::read_write_small_size (void *host_addr, size_t dev_addr, size_t size, bool reading)
{
   UINT8 *ucharptr_host = static_cast<UINT8 *>(host_addr);
   int status;

   for(size_t i = 0; i < size; ++i) {
      if(reading) {
         status = m_io->mem->read8 ( dev_addr+i, ucharptr_host+i);
      } else {
         status = m_io->mem->write8( dev_addr+i, ucharptr_host[i]);
      }
      ACL_PCIE_ERROR_IF(status, return -1, "[%s] failed to read write with odd size.\n", m_name);
   }

   return 0; // success
}

// Set the segment that the memory windows is accessing to
// Return 0 on success
int ACL_PCIE_DEVICE::set_segment( size_t addr )
{
   UINT64 segment_readback;
   UINT64 cur_segment = addr & ~(ACL_PCIE_MEMWINDOW_SIZE-1);
   DWORD  status = 0;

   // Only execute the PCI write if we need to *change* segments
   if ( cur_segment != m_segment )
   {
      // PCIe reordering rules could cause the segment change to get reordered,
	   // so read before and after!
      status |= m_io->window->read64 ( 0 , &segment_readback );

      status |= m_io->window->write64( 0 , cur_segment );
      m_segment = cur_segment;
      ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_BLOCKTX,":::::: [%s] Changed segment id to %llu.\n", m_name, m_segment);

      status |= m_io->window->read64 ( 0 , &segment_readback );
   }

   ACL_PCIE_ERROR_IF(status, return -1, 
      "[%s] failed to set segment for memory access windows.\n", m_name);

   return 0; // success
}

void ACL_PCIE_DEVICE::incr_ptrs (void **host, size_t *dev, size_t *counter, size_t incr)
{
   const uintptr_t uintptr_host = reinterpret_cast<uintptr_t>(*host);

   *host     = reinterpret_cast<void *>(uintptr_host+incr);
   *dev     += incr;
   *counter += incr;
}



// Query the on-chip temperature sensor - this call takes significant time
// so must not be used within performance critical code.
bool ACL_PCIE_DEVICE::get_ondie_temp_slow_call( cl_int *temp )
{
   cl_int read_data;
   
   // We assume this during read later
   ACL_PCIE_ASSERT( sizeof(cl_int) == sizeof(INT32), "sizeof(cl_int) != sizeof(INT32)" );

   if (! ACL_PCIE_HAS_TEMP_SENSOR) {
      ACL_PCIE_DEBUG_MSG(":: [%s] On-chip temperature sensor not supported by this board.\n", m_name);
      return false;
   }

   ACL_PCIE_DEBUG_MSG(":: [%s] Querying on-chip temperature sensor...\n", m_name);
   m_io->temp_sensor->read32(0, (UINT32 *)&read_data);

   ACL_PCIE_DEBUG_MSG(":: [%s] Read temp sensor data.  Value is: %i degrees Celsius\n", m_name, read_data);
   *temp = read_data;
   return true;
}



void *ACL_PCIE_DEVICE::shared_mem_alloc ( size_t size, unsigned long long *device_ptr_out )
{
#if defined(WINDOWS)
   return NULL;
#endif   // WINDOWS
#if defined(LINUX)
   #ifdef ACL_HOST_MEMORY_SHARED
      void *host_ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, m_device, 0); 
      
      if (device_ptr_out != NULL && host_ptr == (void*)-1) {
         // when mmap fails, it returns (void*)-1, not NULL
         host_ptr = NULL;
         *device_ptr_out = (unsigned long long)0;
         
      } else if (device_ptr_out != NULL) {
      
         /* map received host_ptr to FPGA-usable address. */
         void* dev_ptr = NULL;
         struct acl_cmd read_cmd = { ACLPCI_CMD_BAR, 
               ACLPCI_CMD_GET_PHYS_PTR_FROM_VIRT, 
               &dev_ptr,
               &host_ptr,   
               sizeof(dev_ptr) };
               
         bool failed_flag = (read (m_device, &read_cmd, sizeof(dev_ptr)) != 0);
         ACL_PCIE_DEBUG_MSG("  Mapped vaddr %p to phys addr %p. %s\n", 
                  host_ptr, dev_ptr, failed_flag==0 ? "OK" : "FAILED");
         if (failed_flag) {
            *device_ptr_out = (unsigned long long)NULL;
         } else {
            /* When change to 64-bit pointers on the device, update driver code
             * to deal with larger-than-void* ptrs. */
            *device_ptr_out = (unsigned long long)dev_ptr;
            
            /* Now need to add offset of the shared system. */
         } 
      }
      
      return host_ptr;
   #else
      return NULL;
   #endif
#endif   // LINUX
}

void ACL_PCIE_DEVICE::shared_mem_free ( void* vptr, size_t size )
{
#if defined(WINDOWS)
   return;
#endif   // WINDOWS
#if defined(LINUX)
   if (vptr != NULL) {
      munmap (vptr, size);
   }
#endif   // LINUX
}



// Reprogram the device with given binary file.
// There are three ways to program:
// 1. CvP to replace the FPGA core
// 2. Flash to replace the FPGA periphery + core
// 3. Quartus_pgm (USB-Blaster) to replace periphery + core
// USB-Blaster is an old approach, and can only be used when
// when a cable is connected to the board - it remains for testing.
// The default flow is to compare the periphery programmed to the FPGA with
// the periphery of a new design.  If they match, the user's core is
// CvP'ed to the device.  If they differ, the FPGA periphery is replaced by
// programming through the Flash memory.  To get around a silicon bug, a
// base revision compile is programmed to the device through Flash - this
// avoids a PCIe training issue in the silicon, but also programs a
// revision that doesn't contain the user design.  To fix this, after a
// periphery replacement through Flash we immediately perform CvP to
// replace the core with the required user design.
// Return 0 on success
int ACL_PCIE_DEVICE::reprogram(void *data, size_t data_size)
{
   int reprogram_failed = 1;   // assume failure
   const char *SOFNAME  = "reprogram_temp.sof";
   size_t core_rbf_len  = 0, sof_len = 0, dev_id_len = 0;

   struct acl_pkg_file *pkg = acl_pkg_open_file_from_memory( (char*)data, data_size, ACL_PKG_SHOW_ERROR );
   ACL_PCIE_ERROR_IF(pkg == NULL, return reprogram_failed, "cannot open file from memory using pkg editor.\n");

   // check the PCIE device ID in the fpga.bin file and see if it matches with the one on the device.
   ACL_PCIE_ERROR_IF( !acl_pkg_section_exists(pkg, ACL_PKG_SECTION_PCIE_DEV_ID, &dev_id_len),
      return reprogram_failed, "[%s] PCIE_DEV_ID section is not provided in fpga.bin. Can't program the device.\n", m_name );

   char *pcie_dev_id_string = NULL;
   int read_dev_id_ok = acl_pkg_read_section_transient( pkg, ACL_PKG_SECTION_PCIE_DEV_ID, &pcie_dev_id_string);
   ACL_PCIE_ERROR_IF( !read_dev_id_ok, 
      return reprogram_failed, "[%s] Failed while reading PCIE_DEV_ID from fpga.bin. \n", m_name );

   char buf[16] = {0};
   sprintf(buf, "%X", m_info.device_id);
   ACL_PCIE_ERROR_IF( strncmp(buf, pcie_dev_id_string, dev_id_len-1) != 0, return reprogram_failed, 
      "[%s] PCIE Device ID mismatches. Expecting %s, but saw %s", m_name, buf, pcie_dev_id_string);

   // set the being_programmed flag, diable interrupt and save control registers
   m_being_programmed = true;
   this->disable_interrupts();
   m_config->save_pci_control_regs();

   // Environment variable to load the FPGA from a pre-programmed
   // partition in the configuration Flash.  Primarily for testing.
   int flash_partition_to_load_from = 0;
   char *debug_force_flash_load_from_partition = getenv("ACL_PCIE_FORCE_LOAD_FROM_FLASH_PARTITION");
   if (debug_force_flash_load_from_partition) flash_partition_to_load_from = atoi(debug_force_flash_load_from_partition);

   // Environment variable that can override default reprogramming mode.  If
   // set, forces quartus_pgm to be used for periphery replacement instead
   // of Flash.  Quartus_pgm programming currently supports only a single device.
   // This mode/override exists primarily to program a new design onto a
   // board that has an old iface, meaning that we can't access Flash
   // through the iface.  Use this mode to program a new iface, after which
   // aocl flash and periph replacement through Flash will be available.
   unsigned force_periph_replacement_through_usb = 0;
   char *str_force_periph_replacement_through_usb = getenv("ACL_PCIE_FORCE_PERIPH_REPLACE_USB");
   if (str_force_periph_replacement_through_usb) force_periph_replacement_through_usb = 1;

   // Environment variable that prevents CvP from being attempted, and
   // instead forces all reprogram operations to use quartus_pgm.
   // Primarily for use by board vendors as they bring up a new board.
   unsigned always_force_quartus_pgm = 0;
   char *str_always_force_quartus_pgm = getenv("ACL_PCIE_FORCE_USB_PROGRAMMING");
   if (str_always_force_quartus_pgm) always_force_quartus_pgm = 1;

   // Forced reprogramming from Flash partition
   if (debug_force_flash_load_from_partition) {
     assert( flash_partition_to_load_from < SUPPORTED_FLASH_PARTITIONS && "Can only load from Flash paritions 0 or 1" );
     ACL_PCIE_INFO("[%s] Forcing immediate load from flash partition %u\n", m_name, flash_partition_to_load_from);
     reprogram_failed = m_config->reload_fpga_from_flash(
         flash_partition_to_load_from,
         m_name,
         m_flash );

   // CvP or Flash+CvP (for periph update)
   } else if( acl_pkg_section_exists( pkg, ACL_PKG_SECTION_CORE_RBF, &core_rbf_len ) &&
       !always_force_quartus_pgm && !version_id_test() ) {

     // Once on this code path, CvP always runs (see comment descibing the
     // function).  Periphery replacement through Flash only occurs if the
     // peripheries differ.

     // Determine whether the new periphery matches the programmed design
     int periphs_differ = m_flash->does_programmed_periphery_differ_from_fpga_bin( pkg, m_name );

     // Conditional code to replace periphery through Flash, if required
     if ( periphs_differ > 0 && !force_periph_replacement_through_usb ) {
       const int flash_partition = 1;  // Reprogram uses second (non-poweron) partition

       ACL_PCIE_INFO("[%s] New FPGA design has different periphery from programmed design.\n", m_name);

       // First, validate that the base revision we're about to Flash
       // matches the periphery of the target user design that we'll CvP
       // shortly.  A mismatch indicates a failure of some kind during
       // Quartus compilation.  The periphery should have been preserved
       // during the compile.
       reprogram_failed = does_base_periph_match_new_periph( pkg, m_name );

       // Store RBF bitstream to the Flash device (second partition)
       if (!reprogram_failed) {
         reprogram_failed = m_config->flash( pkg,
             flash_partition,
             0 /* make_bootable=0 */,
             m_name,
             m_flash);
       }

       // Trigger a device reprogramming from second Flash partition
       if (!reprogram_failed) {
         reprogram_failed = m_config->reload_fpga_from_flash(
             flash_partition,
             m_name,
             m_flash );
       }


       // Following this code block we CvP the user's core.  Before doing
       // that, we need to restore the PCIe config registers since we just
       // clobbered the PCIe state by reprogramming the FPGA.

       if (!reprogram_failed) {
         // Restore the PCIe state
#if defined(LINUX)
         m_config->load_pci_control_regs();
#endif

         m_config->wait_seconds(1);  // For good measure

         // Disable interrupts and save state prior to CvP
         this->disable_interrupts();
         m_config->save_pci_control_regs();
       }
     } else {
       if (periphs_differ == 0) {
         ACL_PCIE_DEBUG_MSG(":: [%s] New periphery matches existing FPGA configuration.\n", m_name);
       } else {
         ACL_PCIE_DEBUG_MSG(":: [%s] Forcing peripery replacement through quartus_pgm.\n", m_name);
       }
     }
     
     // CvP if peripheries matched, or if we successfully flashed the
     // periphery with a base revision (requiring core replacement on top).
     // Avoid CvPing after a flash failure.
     if ( periphs_differ == 0 || (!force_periph_replacement_through_usb && !reprogram_failed) ) {
       // CvP!

       ACL_PCIE_DEBUG_MSG(":: [%s] Programming core using CvP\n", m_name);
       char *core_rbf = NULL;
       int read_core_rbf_ok = acl_pkg_read_section_transient( pkg, ACL_PKG_SECTION_CORE_RBF, &core_rbf );

       // Kernel driver wants it aligned to 4 bytes.
       int aligned_to_4_bytes( 0 == ( 3 & (uintptr_t)(core_rbf) ) );
       reprogram_failed = 1;  // Default to fail before CvPing
       if(read_core_rbf_ok && !(core_rbf_len % 4) && aligned_to_4_bytes && !version_id_test()) {
         ACL_PCIE_DEBUG_MSG(":: [%s] Starting CvP reprogramming of the device...\n", m_name);   
         reprogram_failed = m_config->program_core_with_CvP_image((int *)core_rbf, core_rbf_len / 4);

         ACL_PCIE_DEBUG_MSG(":: [%s] Sleeping for 50ms to let the link come back up\n", m_name);
#if defined(WINDOWS)
         Sleep( 50 );
#endif   // WINDOWS
#if defined(LINUX)
         usleep(50*1000);
#endif   // LINUX
         if ( reprogram_failed || version_id_test() || wait_for_uniphy() ) {
           reprogram_failed = 1;
           ACL_PCIE_INFO("[%s] failed to program the device through CvP.\n", m_name);
         }
       }
     }
   }

   // fall back to program the device with SOF file if previous attempt failed 
   if( reprogram_failed && acl_pkg_section_exists(pkg, ACL_PKG_SECTION_SOF, &sof_len) ){
      // write out a SOF file
      const int wrote_sof = acl_pkg_read_section_into_file(pkg, ACL_PKG_SECTION_SOF, SOFNAME);
      ACL_PCIE_ERROR_IF( !wrote_sof, return reprogram_failed, "could not write %s.\n", SOFNAME);

      reprogram_failed = m_config->program_with_SOF_file(SOFNAME);
   } 

#if defined(LINUX)
   m_config->load_pci_control_regs();
#endif

   // Clean up
   if ( pkg ) acl_pkg_close_file(pkg);
   m_being_programmed = false;

   return reprogram_failed;
}

// Reprogram a Flash partition with the given binary file.
// Return 0 on success.
int ACL_PCIE_DEVICE::flash(void *data, size_t data_size)
{
   int reprogram_failed = 1;
   struct acl_pkg_file *pkg = acl_pkg_open_file_from_memory( (char*)data, data_size, ACL_PKG_SHOW_ERROR );
   ACL_PCIE_ERROR_IF(pkg == NULL, return reprogram_failed, "Cannot open file from memory using pkg editor.\n");

   // Store RBF bitstream to the Flash device (second partition)
   reprogram_failed = m_config->flash(
       pkg,
       0 /* first Flash partition */,
       1 /* make_bootable=1 */,
       m_name,
       m_flash);

   return reprogram_failed;
}



// Perform a simple version id read to test the basic PCIe read functionality
// Return 0 on success
int ACL_PCIE_DEVICE::version_id_test()
{    
   unsigned int version = ACL_VERSIONID ^ 1; // make sure it's not what we hope to find. 
   unsigned int iattempt;
   unsigned int max_attempts = 1;
   unsigned int usleep_per_attempt = 20;     // 20 ms per.

   ACL_PCIE_DEBUG_MSG(":: [%s] Doing PCIe-to-fabric read test ...\n", m_name);
   for( iattempt = 0; iattempt < max_attempts; iattempt ++){
      m_io->version->read32(0, &version);
      if( version == (unsigned int)ACL_VERSIONID){
         ACL_PCIE_DEBUG_MSG(":: [%s] PCIe-to-fabric read test passed\n", m_name);
         return 0;
      }
#if defined(WINDOWS)
      Sleep(  usleep_per_attempt  );
#endif   // WINDOWS
#if defined(LINUX)
      usleep( usleep_per_attempt*1000 );
#endif   // LINUX
   }

   // Kernel read command succeed, but got bad data. (version id doesn't match)
   ACL_PCIE_INFO("[%s] PCIe-to-fabric read test failed, read 0x%0x after %u attempts\n",
      m_name, version, iattempt);
   return -1;
}

// Wait until the uniphy calibrated
// Return 0 on success
int ACL_PCIE_DEVICE::wait_for_uniphy()
{
   const unsigned int ACL_UNIPHYSTATUS = 0;
   unsigned int status = 1, retries = 0; 
   
   while( retries++ < 8){
      m_io->uniphy_status->read32(0, &status);

      if( status == ACL_UNIPHYSTATUS){
         ACL_PCIE_DEBUG_MSG(":: [%s] Uniphys are calibrated\n", m_name);
         return 0;   // success
      }
#if defined(WINDOWS)
      Sleep( 400 );
#endif   // WINDOWS
#if defined(LINUX)
      usleep(400*1000);
#endif   // LINUX
   }

   ACL_PCIE_INFO("[%s] uniphy(s) did not calibrate.  Expected 0 but read %x\n",
      m_name, status);

   // Failure! Was it communication error or actual calibration failure?
   if ( ACL_PCIE_READ_BIT( status , 3) )  // This bit is hardcoded to 0
      ACL_PCIE_INFO("                Uniphy calibration status is corrupt.  This is likely a communication error with the board and/or uniphy_status module.\n");
   else {
      // This is a 32-bit interface with the first 4 bits aggregating the
      // various calibration signals.  The remaining 28-bits would indicate
      // failure for their respective memory core.  Tell users which ones
      // failed
      for (int i = 0; i < 32-4; i++) {
         if ( ACL_PCIE_READ_BIT( status , 4+i) )
            ACL_PCIE_INFO("  Uniphy core %d failed to calibrate\n",i );
      }
      ACL_PCIE_INFO("     If there are more failures than Uniphy controllers connected, \n");
      ACL_PCIE_INFO("     ensure the uniphy_status core is correctly parameterized.\n" );
   }

   return -1;   // failure
}


// Verify that the periphery hash from the base revision compile matches
// the periphery of the new user design.  Since we first Flash the base
// revision then CvP the user's core, any mismatches are fatal and can
// bring down the PCIe device.
// Returns:
//    0 if peripheries are the same
//    1 if peripheries differ
//    -1 on error
int ACL_PCIE_DEVICE::does_base_periph_match_new_periph( struct acl_pkg_file *pkg, const char* dev_name )
{
  size_t hash_len = 0;

  // Verify that required sections exists in fpga.bin
  ACL_PCIE_ERROR_IF( !acl_pkg_section_exists( pkg, ACL_PKG_SECTION_PERIPH_HASH, &hash_len ), 
      return -1, "[%s] fpga.bin doesn't contain periphery hash section (%s).  Can't configure device.\n", dev_name, ACL_PKG_SECTION_PERIPH_HASH);
  ACL_PCIE_ERROR_IF( !acl_pkg_section_exists( pkg, ACL_PKG_SECTION_BASE_PERIPH_HASH, &hash_len ), 
      return -1, "[%s] fpga.bin doesn't contain base periphery hash section (%s).  Can't configure device.\n", dev_name, ACL_PKG_SECTION_BASE_PERIPH_HASH);

  char *cvp_periph_hash = NULL;
  char *base_periph_hash = NULL;
  int read_hash_ok = acl_pkg_read_section_transient( pkg, ACL_PKG_SECTION_PERIPH_HASH, &cvp_periph_hash );
  ACL_PCIE_ERROR_IF( !read_hash_ok, 
      return -1, ":: [%s] Failed while reading cvp periphery hash from fpga.bin...\n", dev_name);

  read_hash_ok = acl_pkg_read_section_transient( pkg, ACL_PKG_SECTION_BASE_PERIPH_HASH, &base_periph_hash );
  ACL_PCIE_ERROR_IF( !read_hash_ok, 
      return -1, ":: [%s] Failed while reading base periphery hash from fpga.bin...\n", dev_name);

  ACL_PCIE_DEBUG_MSG(":: [%s] CvP periphery hash in fpga.bin=", dev_name);
  for (unsigned i=0; i < PERIPH_HASH_LENGTH_BYTES*2; i++) ACL_PCIE_DEBUG_MSG("%c", cvp_periph_hash[i]);
  ACL_PCIE_DEBUG_MSG("\n");

  ACL_PCIE_DEBUG_MSG(":: [%s] Base periphery hash in fpga.bin=", dev_name);
  for (unsigned i=0; i < PERIPH_HASH_LENGTH_BYTES*2; i++) ACL_PCIE_DEBUG_MSG("%c", base_periph_hash[i]);
  ACL_PCIE_DEBUG_MSG("\n");
  
  // Compare the hash strings.  Length is bytes*2 because encoded as hex
  // char string.
  for ( unsigned i=0; i < PERIPH_HASH_LENGTH_BYTES*2; i++ ) {
    if ( cvp_periph_hash[i] != base_periph_hash[i] ) {
      ACL_PCIE_DEBUG_MSG(":: [%s] First periphery hash mismatch on character %u. Base=%x, CvP=%x\n",
          dev_name, i, base_periph_hash[i], cvp_periph_hash[i] );
      ACL_PCIE_INFO("AOCX base and CvP periphery hashes differ.  Programming will fail in hardware, so aborting.\n");
      return 1;  // Return "periphs differ"
    }
  }

  return 0;  // No mismatches.  Return "periphs identical"
}


static UINT32 ip_string_to_int ( const char * ip_str ) {
   int ip = 0;
   int i = 0;

   char buf[50];
   strncpy(buf,ip_str,50);

   char * p = strtok(buf,".");
   while ( p && i < 5 ) {
      ip = (ip << 8 ) | atoi( p );
      p = strtok(NULL,".");
      i++;
   }
   ACL_PCIE_ERROR_IF( i != 4 , return 0, ":: QuickUDP Invaid ip specified: %s\n",ip_str);

   return (UINT32)ip;
}

static UINT64 mac_string_to_int64 ( const char * mac_str ) 
{
   UINT64 mac = 0;
   int i = 0;

   char buf[50];
   strncpy(buf,mac_str,50);

   char * p = strtok(buf,":");
   while ( p && i < 7 ) {
      mac = (mac << 8 ) | strtoul( p, NULL, 16) ;
      p = strtok(NULL,":");
      i++;
   }
   ACL_PCIE_ERROR_IF( i != 6 , return 0, ":: QuickUDP Invaid mac specified: %s\n",mac_str);

   return mac;
}

bool ACL_PCIE_DEVICE::quickudp_init(int core_id, const char * mac, const char * ip, const char * subnet_mask)
{
   ACL_PCIE_QUICKUDP * qudp;
   if (core_id == 0 )
      qudp = m_quickudp0 = new ACL_PCIE_QUICKUDP( m_io->quickudp0 );
   else
      qudp = m_quickudp1 = new ACL_PCIE_QUICKUDP( m_io->quickudp1 );

   UINT64 mac_addr = mac_string_to_int64 ( mac );
   return qudp->configure( 
         (UINT32)(mac_addr & 0x0ffffffffll),
         (UINT32)(mac_addr >> 32l),
         ip_string_to_int( ip ),
         ip_string_to_int( subnet_mask ));
}

bool ACL_PCIE_DEVICE::quickudp_open_session(int core_id, int session_id, short rx_port, const char * tx_dst_ip, short tx_src_port, short tx_dst_port)
{
   ACL_PCIE_QUICKUDP * qudp;
   if (core_id == 0 )
      qudp = m_quickudp0;
   else 
      qudp = m_quickudp1;

   ACL_PCIE_ERROR_IF( qudp == NULL, return false, ":: QuickUDP core %d must be initialized before opening session\n",core_id);

   bool qudp_ok = qudp->open_session( session_id, rx_port, tx_src_port, tx_dst_port, 
         ip_string_to_int(tx_dst_ip) );

   ACL_PCIE_ERROR_IF ( !qudp_ok , return false, ":: QuickUDP %d session %d failed to open\n",core_id,session_id);
   return true;
}

