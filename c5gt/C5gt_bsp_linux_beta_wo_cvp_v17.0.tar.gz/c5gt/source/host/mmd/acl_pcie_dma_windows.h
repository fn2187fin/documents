#ifndef ACL_PCIE_DMA_WINDOWS_H
#define ACL_PCIE_DMA_WINDOWS_H

/* (C) 1992-2017 Intel Corporation.                             */
/* Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words     */
/* and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.   */
/* and/or other countries. Other marks and brands may be claimed as the property   */
/* of others. See Trademarks on intel.com for full list of Intel trademarks or     */
/* the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera)  */
/* Your use of Intel Corporation's design tools, logic functions and other         */
/* software and tools, and its AMPP partner logic functions, and any output        */
/* files any of the foregoing (including device programming or simulation          */
/* files), and any associated documentation or information are expressly subject   */
/* to the terms and conditions of the Altera Program License Subscription          */
/* Agreement, Intel MegaCore Function License Agreement, or other applicable       */
/* license agreement, including, without limitation, that your use is for the      */
/* sole purpose of programming logic devices manufactured by Intel and sold by     */
/* Intel or its authorized distributors.  Please refer to the applicable           */
/* agreement for further details.                                                  */


/* ===- acl_pcie_dma_windows.h  --------------------------------------- C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file declares the class to handle Windows-specific DMA operations.         */
/* The actual implementation of the class lives in the acl_pcie_dma_windows.cpp      */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */


#if defined(WINDOWS)

#include "hw_pcie_dma.h"

#include <queue>
#include <windows.h>

class ACL_PCIE_DEVICE;
class ACL_PCIE_MM_IO_MGR;
class ACL_PCIE_TIMER;

class ACL_PCIE_DMA
{
   public:
      ACL_PCIE_DMA( WDC_DEVICE_HANDLE dev, ACL_PCIE_MM_IO_MGR *io, ACL_PCIE_DEVICE *pcie );
      ~ACL_PCIE_DMA();

      bool is_idle() { return m_idle; };
      void stall_until_idle(){ while(!is_idle()) yield(); };

      // Perform operations required when a DMA interrupt comes
      void service_interrupt();

      // Relinquish the CPU to let any other thread to run
      // Return 0 since there is no useful work to be performed here
      int  yield();

      // Transfer data between host and device
      // This function returns right after the transfer is scheduled
      // Return 0 on success
      int read_write(void *host_addr, size_t dev_addr, size_t bytes, aocl_mmd_op_t e, bool reading);

      // the callback function to be scheduled inside the interrupt handler
      friend void CALLBACK myWorkCallback(PTP_CALLBACK_INSTANCE instance, void *context, PTP_WORK work);

   private:

      struct PINNED_MEM
      {
         WD_DMA_PAGE *next_page;
         DWORD pages_rem;
         WD_DMA *dma;
      };

      // function to be scheduled to execute whenever an interrupt arrived
      bool update( bool force_update=false );

      // Helper functions
      inline bool  pending_dma_full();
      inline bool  hardware_buffers_full();
      inline bool  ready_for_data();
      inline void *compute_address( void* base, uintptr_t offset );
      void         set_att_entry( KPTR address, unsigned int row );
      void         send_active_descriptor();

      // The container of pending memory transactions
      std::queue< WD_DMA* >                m_dma_pending;
      // A representation of the hardware's descriptor fifo
      std::queue< DESCRIPTOR_UPDATE_DATA > m_desc_pending;

      // The dma object we are currently building transactions for
      PINNED_MEM m_active_mem;
      
      // The transaction we are currently working on
      DMA_DESCRIPTOR m_active_descriptor;
      unsigned int   m_active_descriptor_size;
      bool           m_active_descriptor_valid;

      unsigned int m_descriptors_updated;
      unsigned int m_descriptors_acknowledged;
      size_t       m_bytes_acknowledged;
      size_t       m_bytes_sent;
      UINT32       m_old_done_count;

      unsigned int m_next_att_row;  // The next ATT table row to write to
      unsigned int m_att_size;      // The total number of active ATT rows

      // variables for the read/write request
      aocl_mmd_op_t m_event;
      size_t        m_dev_addr;
      void*         m_host_addr;
      size_t        m_bytes;
      bool          m_read;
      bool          m_idle;

      WDC_DEVICE_HANDLE   m_device;
      ACL_PCIE_DEVICE    *m_pcie;
      ACL_PCIE_MM_IO_MGR *m_io;
      ACL_PCIE_TIMER     *m_timer;

      // variables needed for the threadpool and works that submitted to it
      TP_CALLBACK_ENVIRON m_callback_env;
      PTP_POOL            m_threadpool;
      PTP_WORK            m_work;

      // This variable is accessed by the callback function defined in acl_pcie_dma_windows.cpp
      // This semaphore is intended to keep at most 1 work in queued (not running)
      HANDLE m_workqueue_semaphore;
};

#endif // WINDOWS

#endif // ACL_PCIE_DMA_WINDOWS_H
