// (C) 1992-2017 Intel Corporation.                            
// Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words    
// and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.  
// and/or other countries. Other marks and brands may be claimed as the property  
// of others. See Trademarks on intel.com for full list of Intel trademarks or    
// the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera) 
// Your use of Intel Corporation's design tools, logic functions and other        
// software and tools, and its AMPP partner logic functions, and any output       
// files any of the foregoing (including device programming or simulation         
// files), and any associated documentation or information are expressly subject  
// to the terms and conditions of the Altera Program License Subscription         
// Agreement, Intel MegaCore Function License Agreement, or other applicable      
// license agreement, including, without limitation, that your use is for the     
// sole purpose of programming logic devices manufactured by Intel and sold by    
// Intel or its authorized distributors.  Please refer to the applicable          
// agreement for further details.                                                 


/* ===- acl_pcie_dma_windows.cpp  ------------------------------------- C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file implements the class to handle Windows-specific DMA operations.       */
/* The declaration of the class lives in the acl_pcie_dma_windows.h                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */


#if defined(WINDOWS)

// common and its own header files
#include "acl_pcie.h"
#include "acl_pcie_dma_windows.h"

// other header files inside MMD driver
#include "acl_pcie_device.h"
#include "acl_pcie_mm_io.h"
#include "acl_pcie_timer.h"
#include "acl_pcie_debug.h"


#define ACL_PCIE_DMA_DEBUG(m, ...)  ACL_PCIE_DEBUG_MSG_VERBOSE(VERBOSITY_BLOCKTX, m, __VA_ARGS__)



// The callback function to be scheduled inside the interrupt handler
// It will release the semaphore to allow new work to be scheduled and 
// perform the dma update function
void CALLBACK myWorkCallback(PTP_CALLBACK_INSTANCE instance, void *context, PTP_WORK work){
   ACL_PCIE_DMA *m_dma = (ACL_PCIE_DMA *)context;
   
   ReleaseSemaphore(m_dma->m_workqueue_semaphore, 1, NULL);
   
   m_dma->update(true);
}

ACL_PCIE_DMA::ACL_PCIE_DMA( WDC_DEVICE_HANDLE dev, ACL_PCIE_MM_IO_MGR *io, ACL_PCIE_DEVICE *pcie ) :
   m_active_descriptor_valid( false ),
   m_att_size( 0 ),
   m_event( NULL ),
   m_pcie( NULL ),
   m_io( NULL ),
   m_timer( NULL )
{
   ACL_PCIE_ASSERT(dev  != INVALID_DEVICE, "passed in an invalid device when creating dma object.\n");
   ACL_PCIE_ASSERT(io   != NULL, "passed in an empty pointer for io when creating dma object.\n");
   ACL_PCIE_ASSERT(pcie != NULL, "passed in an empty pointer for pcie when creating dma object.\n");
   
   m_device = dev;
   m_io     = io;
   m_pcie   = pcie;

   memset( &m_active_mem, 0, sizeof(PINNED_MEM) );

   // reset the "done-count" register
   m_old_done_count = 0;
   m_io->dma->write32(DMA_CSR_STATUS, ACL_PCIE_GET_BIT(DMA_STATUS_COUNT_LO));

   m_timer = new ACL_PCIE_TIMER();

   // create the threadpool to perform work the interrupt
   m_threadpool = CreateThreadpool(NULL);
   ACL_PCIE_ERROR_IF( m_threadpool == NULL, return, "failed to create threadpool.\n" );

   // set the number of work threads to 1 
   // so that no scheduled work will be running in parallel between them
   SetThreadpoolThreadMaximum(m_threadpool, 1);  
   bool status = SetThreadpoolThreadMinimum(m_threadpool, 1);
   ACL_PCIE_ERROR_IF( status == false, return, "failed to set # of work thread to 1.\n" );

   // create the work for threadpool and its semaphore
   InitializeThreadpoolEnvironment(&m_callback_env);   
   SetThreadpoolCallbackPool(&m_callback_env, m_threadpool);

   m_work = CreateThreadpoolWork(myWorkCallback, (void *)this, &m_callback_env);
   ACL_PCIE_ERROR_IF( m_work == NULL, return, "failed to create work for threadpool.\n" );
   
   m_workqueue_semaphore = CreateSemaphore(NULL, 1, 1, NULL);
   ACL_PCIE_ERROR_IF( m_workqueue_semaphore == NULL, return, "failed to create semaphore.\n" );

   // set idle status to true when finish initialization
   m_idle = true;
}

ACL_PCIE_DMA::~ACL_PCIE_DMA()
{
   stall_until_idle();
   
   // make sure no more work queued for threadpool
   WaitForThreadpoolWorkCallbacks(m_work, FALSE);

   CloseHandle(m_workqueue_semaphore);
   CloseThreadpoolWork(m_work);
   CloseThreadpool(m_threadpool);
   
   if( m_timer ) { delete m_timer;  m_timer = NULL; }
}



// Perform operations required when a DMA interrupt comes
void ACL_PCIE_DMA::service_interrupt()
{
   UINT32 dma_status;
   UINT32 done_count;

   // Clear the IRQ bit
   m_io->dma->write32(DMA_CSR_STATUS, ACL_PCIE_GET_BIT(DMA_STATUS_IRQ));

   // Read the DMA status register
   m_io->dma->read32( DMA_CSR_STATUS, &dma_status );

   // Compute how many descriptors completed
   done_count = ACL_PCIE_READ_BIT_RANGE( dma_status, DMA_STATUS_COUNT_HI, DMA_STATUS_COUNT_LO );
   // The done_count counter can wrap around - but it's not possible for it to wrap more than
   // once in a single update.
   if(done_count < m_old_done_count)
      m_descriptors_acknowledged += (done_count + ACL_PCIE_DMA_MAX_DONE_COUNT - m_old_done_count);
   else
      m_descriptors_acknowledged += (done_count - m_old_done_count);
   m_old_done_count = done_count;
   
   // only submit a new work to the pool when there is not work in queued
   if( WaitForSingleObject(m_workqueue_semaphore, 0L) == WAIT_OBJECT_0 ){
      SubmitThreadpoolWork(m_work);
   }
}



// Relinquish the CPU to let any other thread to run
// Return 0 since there is no useful work to be performed here
int ACL_PCIE_DMA::yield()
{
   Sleep(0);
   return 0;
}



// Transfer data between host and device
// This function returns right after the transfer is scheduled
// Return 0 on success
int ACL_PCIE_DMA::read_write(void *host_addr, size_t dev_addr, size_t bytes, aocl_mmd_op_t e, bool reading)
{
   ACL_PCIE_ASSERT( m_event == NULL, "non-empty event before a new DMA read/write.\n" );
   ACL_PCIE_ASSERT( m_dma_pending.empty(), "dma pending queues is not empty before a new DMA read/write.\n" );
   ACL_PCIE_ASSERT( m_desc_pending.empty(), "descriptor pending queues is not empty before a new DMA read/write.\n" );
   ACL_PCIE_ASSERT( m_active_mem.dma == NULL, "there is still active pinned memory before a new DMA read/write.\n" );
   ACL_PCIE_ASSERT( !m_active_descriptor_valid, "there is still active descriptor before a new DMA read/write.\n" );
   ACL_PCIE_ASSERT( m_att_size == 0, "there is still active ATT entry before a new DMA read/write.\n" );

   // Copy the parameters over and mark the job as running
   m_event     = e;
   m_read      = reading;
   m_bytes     = bytes;
   m_host_addr = host_addr;
   m_dev_addr  = dev_addr;

   // Start processing the request
   m_descriptors_updated      = 0;
   m_descriptors_acknowledged = 0;
   m_bytes_acknowledged       = 0;
   m_bytes_sent               = 0;
   m_next_att_row             = 0;

   m_idle                     = false;

   // setup the work inside the threadpool to perform the first DMA transaction
   ACL_PCIE_ERROR_IF( WaitForSingleObject(m_workqueue_semaphore, 0L) != WAIT_OBJECT_0, return -1, 
            "failed to schedule the first work for DMA read/write.\n" );

   SubmitThreadpoolWork(m_work);

   return 0; // success
}



// function to be scheduled to execute whenever an interrupt arrived
bool ACL_PCIE_DMA::update( bool forced )
{
   DWORD WD_status;

   if((m_descriptors_updated == m_descriptors_acknowledged) && !forced)
      return false;

   // Process any descriptors that have completed
   cl_ulong finish = 0;
   if ( ACL_PCIE_DEBUG >= VERBOSITY_BLOCKTX )
     finish = m_timer->get_time_ns();

   ACL_PCIE_DMA_DEBUG(":::: [DMA] Descriptors: Updated - %u, Acknowledged - %u (forced %d)\n", m_descriptors_updated, m_descriptors_acknowledged, forced);
   while(m_descriptors_updated < m_descriptors_acknowledged)
   {
      ACL_PCIE_ASSERT(!m_desc_pending.empty(), "DMA descriptor pending queue is empty when an interrupt received.\n");
      m_bytes_acknowledged += m_desc_pending.front().bytes;
      m_att_size -= m_desc_pending.front().att_entries;
      ACL_PCIE_DMA_DEBUG(":::: [DMA] Descriptor (%d bytes) completed in %.2f us - %.2f MB/s \n", 
                     m_desc_pending.front().bytes,
                     (finish - m_desc_pending.front().start) / 1000.0,
                     1000000000.0 * m_desc_pending.front().bytes / (finish - m_desc_pending.front().start) / (1024.0 * 1024.0));
      m_desc_pending.pop();
      ++m_descriptors_updated;
   }
   ACL_PCIE_DMA_DEBUG( ":::: [DMA] %u descriptors pending...\n", m_desc_pending.size());

   // Process any pinned memory that is no longer required
   while( (m_bytes_acknowledged > 0) && !m_dma_pending.empty() && (m_dma_pending.front()->dwBytes <= m_bytes_acknowledged) )
   {
      WD_DMA *dma = m_dma_pending.front();
      m_dma_pending.pop();
      m_bytes_acknowledged -= dma->dwBytes;

      WD_status = WDC_DMASyncIo(dma);
      ACL_PCIE_ASSERT( WD_status == WD_STATUS_SUCCESS, "WDC_DMASyncIo function failed.\n" );      
      WD_status = WDC_DMABufUnlock(dma );
      ACL_PCIE_ASSERT( WD_status == WD_STATUS_SUCCESS, "WDC_DMABufUnlock function failed.\n" );
   }
   ACL_PCIE_DMA_DEBUG( ":::: [DMA] %u dma buffers pending...\n", m_dma_pending.size());
   ACL_PCIE_DMA_DEBUG( ":::: [DMA] %lu bytes pending...\n", (m_bytes - m_bytes_sent));

   // Check if the transaction is complete
   if( (m_bytes_sent == m_bytes) && m_dma_pending.empty() )
   {
      ACL_PCIE_DMA_DEBUG( ":::: [DMA] Transaction complete!\n" );

      ACL_PCIE_ASSERT( m_dma_pending.empty(), "dma pending queues is not empty after the DMA read/write.\n" );
      ACL_PCIE_ASSERT( m_desc_pending.empty(), "descriptor pending queues is not empty after the DMA read/write.\n" );
      ACL_PCIE_ASSERT( m_active_mem.dma == NULL, "there is still active pinned memory after the DMA read/write.\n" );
      ACL_PCIE_ASSERT( !m_active_descriptor_valid, "there is still active descriptor after the DMA read/write.\n" );
      ACL_PCIE_ASSERT( m_att_size == 0, "there is still active ATT entry after the DMA read/write.\n" );

      m_idle = true;
      if (m_event) 
      {
         // Use a temporary variable to save the event data and reset m_event before calling event_update_fn 
         // to avoid race condition that the main thread may start a new DMA transfer before this work-thread
         // is able to reset the m_event.
         aocl_mmd_op_t temp_event = m_event;
         m_event = NULL; 

         m_pcie->event_update_fn( temp_event, 0 );  
      }

      return true;
   }

   // Send as much data as the HW can accept
   while( this->ready_for_data() )
   {
      if(m_active_mem.dma == NULL)
      {
         // No active segment of pinned memory - pin one
         DWORD lock_options = static_cast<DWORD>((m_read?DMA_FROM_DEVICE:DMA_TO_DEVICE) | DMA_ALLOW_64BIT_ADDRESS);
         size_t bytes_rem    = (m_bytes-m_bytes_sent);
         size_t lock_size    = (bytes_rem > ACL_PCIE_DMA_MAX_PINNED_MEM_SIZE) ? ACL_PCIE_DMA_MAX_PINNED_MEM_SIZE : bytes_rem;
         void* lock_addr    = this->compute_address(m_host_addr, m_bytes_sent);
         uintptr_t last_page_portion = (reinterpret_cast<uintptr_t>(lock_addr) + lock_size) & ACL_PCIE_DMA_ATT_PAGE_ADDR_MASK;
         // If doing max pinning, check if will *end* on page boundary. If not, better
         // to pin a bit less and end up on the boundary. This way, will have fewer
         // descriptors to send.
         if (lock_size == ACL_PCIE_DMA_MAX_PINNED_MEM_SIZE && last_page_portion != 0) {
            lock_size -= (size_t)last_page_portion;
         }
         
         assert(lock_size < MAXDWORD);
         WD_status = WDC_DMASGBufLock(m_device, lock_addr, lock_options, (DWORD)lock_size, &m_active_mem.dma );
         ACL_PCIE_ASSERT( WD_status == WD_STATUS_SUCCESS, "WDC_DMASGBufLock function failed.\n" );
         WD_status = WDC_DMASyncCpu( m_active_mem.dma );
         ACL_PCIE_ASSERT( WD_status == WD_STATUS_SUCCESS, "WDC_DMASyncCpu function failed.\n" );

         m_active_mem.pages_rem = m_active_mem.dma->dwPages;
         m_active_mem.next_page = m_active_mem.dma->Page;

         ACL_PCIE_DMA_DEBUG( ":::: [DMA] Pinning 0x%x bytes at 0x%p.\n", lock_size, lock_addr );
         ACL_PCIE_DMA_DEBUG( ":::: [DMA] Pinned %d pages for 0x%x bytes of memory.\n", m_active_mem.dma->dwPages, m_active_mem.dma->dwBytes );
      }

      // As long as the hardware FIFOs are not full, populate them with transfer requests
      while( !hardware_buffers_full() && (m_active_mem.pages_rem > 0) )
      {
         WD_DMA_PAGE att_page;
         DWORD max_page_size;

         // Peek at the next ATT page
         att_page.pPhysicalAddr = m_active_mem.next_page->pPhysicalAddr;
         // If we begin with an offset, we can't use the full page
         max_page_size    = ACL_PCIE_DMA_MAX_ATT_PAGE_SIZE - (att_page.pPhysicalAddr & ACL_PCIE_DMA_ATT_PAGE_ADDR_MASK);
         att_page.dwBytes = (m_active_mem.next_page->dwBytes > max_page_size) ? max_page_size : m_active_mem.next_page->dwBytes;

         m_active_mem.next_page->dwBytes -= att_page.dwBytes;
         m_active_mem.next_page->pPhysicalAddr += att_page.dwBytes;
         if(m_active_mem.next_page->dwBytes == 0)
         {
            ++m_active_mem.next_page;
            --m_active_mem.pages_rem;
         }

         // If this transfer does not begin on a page boundary, then we need to create a new
         // descriptor for it
         if(m_active_descriptor_valid && (att_page.pPhysicalAddr & ACL_PCIE_DMA_ATT_PAGE_ADDR_MASK) != 0)
            this->send_active_descriptor();

         // If there is no active descriptor, create a new one
         if(!m_active_descriptor_valid)
         {
#define HI32(X) ((unsigned int)(((unsigned long long)X)>>32))
#define LO32(X) ((unsigned int)(((unsigned long long)X) & 0x0ffffffffll))
            size_t pcietxs_addr = (size_t)ACL_PCIE_TX_PORT | (m_next_att_row * ACL_PCIE_DMA_MAX_ATT_PAGE_SIZE) | (att_page.pPhysicalAddr & ACL_PCIE_DMA_ATT_PAGE_ADDR_MASK);
            size_t gmem_addr = m_dev_addr + m_bytes_sent;

            m_active_descriptor.read_address = m_read ? LO32(gmem_addr) : LO32(pcietxs_addr);
            m_active_descriptor.write_address = m_read ? LO32(pcietxs_addr) : LO32(gmem_addr);
            m_active_descriptor.bytes = 0;  // Updated below
            m_active_descriptor.burst = 0;
            m_active_descriptor.stride = 0x00010001;
            m_active_descriptor.read_address_hi = m_read ? HI32(gmem_addr) : HI32(pcietxs_addr);
            m_active_descriptor.write_address_hi =  m_read ? HI32(pcietxs_addr) : HI32(gmem_addr);
            m_active_descriptor_size = 0;
            m_active_descriptor_valid = true;
#undef HI32
#undef LO32
         }

         // Write out this ATT page, add it to the descriptor, update the bytes sent counter
         this->set_att_entry( att_page.pPhysicalAddr, m_next_att_row );
         m_next_att_row = (m_next_att_row + 1) % ACL_PCIE_DMA_MAX_ATT_SIZE;
         ++m_active_descriptor_size;
         m_active_descriptor.bytes += static_cast<UINT32>(att_page.dwBytes);
         m_bytes_sent += att_page.dwBytes;

         // If this descriptor cannot be merged with the next ATT page, send it now
         if( (((att_page.pPhysicalAddr + att_page.dwBytes) & ACL_PCIE_DMA_ATT_PAGE_ADDR_MASK) != 0) ||
             (m_next_att_row == 0) ||
             (m_active_descriptor_size == ACL_PCIE_DMA_MAX_ATT_PER_DESCRIPTOR) )
         {
            this->send_active_descriptor();
         }
      }

      // If we finished the active page, push it into the list of pending DMAs
      if( m_active_mem.pages_rem == 0 )
      {
         if(m_active_descriptor_valid && !hardware_buffers_full())
            this->send_active_descriptor();
         m_dma_pending.push( m_active_mem.dma );
         m_active_mem.dma = NULL;
      }
      ACL_PCIE_DMA_DEBUG( ":::: [DMA] %u pages remain.\n", m_active_mem.pages_rem);
   }

   // There may be one last descriptor to send
   if(m_active_descriptor_valid && !hardware_buffers_full())
      this->send_active_descriptor();

   return true;
}



// We can only pin a limited amount of memory
inline bool ACL_PCIE_DMA::pending_dma_full() 
{
   return m_dma_pending.size() >= ACL_PCIE_DMA_MAX_PINNED_MEM; 
}

// Checks our representation of the hardware FIFOs to verify they are not full
inline bool ACL_PCIE_DMA::hardware_buffers_full() 
{
   return (m_desc_pending.size() >= ACL_PCIE_DMA_MAX_DESCRIPTORS) || 
            (m_att_size >= ACL_PCIE_DMA_MAX_ATT_SIZE); 
}

// If there is an active transfer, check that the hardware is free to accept
// more data; otherwise, check that there is more data to send and we are
// free to lock a new buffer
inline bool ACL_PCIE_DMA::ready_for_data() 
{
   return (m_active_mem.dma == NULL) ? 
      (m_bytes_sent < m_bytes) && !pending_dma_full() : !hardware_buffers_full(); 
}

// Add a byte-offset to a void* pointer
inline void *ACL_PCIE_DMA::compute_address( void* base, uintptr_t offset )
{
   uintptr_t p = reinterpret_cast<uintptr_t>(base);
   return reinterpret_cast<void*>(p + offset);
}

void ACL_PCIE_DMA::set_att_entry( KPTR address, unsigned int row )
{
   bool is64bit = ((address & 0xffffffff00000000ULL) != 0ULL);
   if(is64bit) {
      ACL_PCIE_DMA_DEBUG( ":::: [DMA] Set 64bit-ATT[%d] = 0x%p\n", row, address );
      m_io->pcie_cra->write64( PCIE_CRA_ADDR_TRANS + row*8, ((address & 0xfffffffffffffffcULL) | 0x1) );
   } else {
      ACL_PCIE_DMA_DEBUG( ":::: [DMA] Set 32bit-ATT[%d] = 0x%x\n", row, address );
      m_io->pcie_cra->write32( PCIE_CRA_ADDR_TRANS + row*8, (static_cast<UINT32>(address) & 0x00000000fffffffcULL) );
   }
   ++m_att_size;
}

void ACL_PCIE_DMA::send_active_descriptor()
{
   DESCRIPTOR_UPDATE_DATA d;

   ACL_PCIE_DMA_DEBUG( ":::: [DMA] Sent descriptor 0x%p -> 0x%p (%d ATT entries, 0x%x bytes)\n", 
                     m_active_descriptor.read_address,
                     m_active_descriptor.write_address,
                     m_active_descriptor_size, 
                     m_active_descriptor.bytes);
   
   // DMA controller is setup to only handle aligned requests - verify this is an aligned request
   // If this fails, I think we need to bite the bullet and write our own DMA
   if(((m_active_descriptor.read_address & DMA_ALIGNMENT_BYTE_MASK) != 0) ||
      ((m_active_descriptor.write_address & DMA_ALIGNMENT_BYTE_MASK) != 0) ||
      ((m_active_descriptor.bytes & DMA_ALIGNMENT_BYTE_MASK) != 0) )
   {
      ACL_PCIE_ASSERT(0, "attempted to send unaligned descriptor, 0x%p -> 0x%p (%d ATT entries, 0x%x bytes)\n", 
              m_active_descriptor.read_address,
              m_active_descriptor.write_address,
              m_active_descriptor_size, 
              m_active_descriptor.bytes);
   }

   // send the active descriptor
   ACL_PCIE_ASSERT(m_active_descriptor_valid, "invalid active description\n");
   m_active_descriptor.control = static_cast<UINT32>( ACL_PCIE_GET_BIT(DMA_DC_GO) | 
                                   ACL_PCIE_GET_BIT(DMA_DC_EARLY_DONE_ENABLE) |
                                   ACL_PCIE_GET_BIT(DMA_DC_TRANSFER_COMPLETE_IRQ_MASK) );
   m_io->dma_descriptor->write_block(0, sizeof(DMA_DESCRIPTOR), &m_active_descriptor );

   // push the info of the sent descriptor into the queue
   d.bytes       = m_active_descriptor.bytes;
   d.att_entries = m_active_descriptor_size;
   d.start       = m_timer->get_time_ns();
   m_desc_pending.push( d );
   m_active_descriptor_valid = false;
}


#endif // WINDOWS
