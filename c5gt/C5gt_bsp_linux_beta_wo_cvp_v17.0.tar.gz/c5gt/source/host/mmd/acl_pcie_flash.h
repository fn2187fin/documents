#ifndef ACL_PCIE_FLASH_H
#define ACL_PCIE_FLASH_H

/* (C) 1992-2017 Intel Corporation.                             */
/* Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words     */
/* and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.   */
/* and/or other countries. Other marks and brands may be claimed as the property   */
/* of others. See Trademarks on intel.com for full list of Intel trademarks or     */
/* the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera)  */
/* Your use of Intel Corporation's design tools, logic functions and other         */
/* software and tools, and its AMPP partner logic functions, and any output        */
/* files any of the foregoing (including device programming or simulation          */
/* files), and any associated documentation or information are expressly subject   */
/* to the terms and conditions of the Altera Program License Subscription          */
/* Agreement, Intel MegaCore Function License Agreement, or other applicable       */
/* license agreement, including, without limitation, that your use is for the      */
/* sole purpose of programming logic devices manufactured by Intel and sold by     */
/* Intel or its authorized distributors.  Please refer to the applicable           */
/* agreement for further details.                                                  */


/* ===- acl_pcie_flash.h  --------------------------------------------- C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file declares routines and constants to reprogram the FPGA configuration   */
/* FLASH.                                                                          */
/* Implementation is in acl_pcie_flash.cpp.                                        */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */

// Visual Studio doesn't include stdint.h, so doesn't have types like utin64_t.  Defining
// as a VS type when using that compiler.
#ifdef _MSC_VER
typedef unsigned __int8 uint8_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#endif

#define EXTRACT_BIT(VALUE,BIT) (((VALUE) >> (BIT)) & 0x1)

// Board-specific FLASH configuration constants
#define CPLD_ROUTER_TARGET_CPLD           (0x1)
#define CPLD_ROUTER_TARGET_FLASH          (0x4)

#define CPLD_READ_OP                      (0x0)
#define CPLD_WRITE_OP                     (0x1)
#define CPLD_ACK_OP                       (0x2)

// Following are BYTE addresses
#define CPLD_REGMAP_CPLD_ID               (0x0000)
#define CPLD_REGMAP_FLASH_STATUS          (0x1000)
#define CPLD_REGMAP_CLOCK_STATUS          (0x1002)
#define CPLD_REGMAP_MISC_STATUS0          (0x1004)
#define CPLD_REGMAP_MISC_STATUS1          (0x1006)
#define CPLD_REGMAP_QSFP_STATUS           (0x1008)
#define CPLD_REGMAP_JTAG_STATUS           (0x100A)
#define CPLD_REGMAP_BOOT_LD_STATUS        (0x100C)
#define CPLD_REGMAP_FPGA_A_CFG_STATUS     (0x100E)
#define CPLD_REGMAP_FPGA_B_CFG_STATUS     (0x1010)
#define CPLD_REGMAP_FPGA_C_CFG_STATUS     (0x1012)
#define CPLD_REGMAP_FLASH_CONTROL         (0x2000)
#define CPLD_REGMAP_POWER_CONTROL         (0x2002)
#define CPLD_REGMAP_MISC_CONTROL          (0x2004)
#define CPLD_REGMAP_FPGA_CONFIG_CONTROL   (0x2006)
#define CPLD_REGMAP_MANUAL_BOOT_CONTROL   (0x2008)
#define CPLD_REGMAP_UART_ROUTER0_CONTROL  (0x200A)
#define CPLD_REGMAP_UART_ROUTER1_CONTROL  (0x200C)
#define CPLD_REGMAP_MISC_BIDIR_CONTROL    (0x3000)
#define CPLD_REGMAP_QSFP_BIDIR_CONTROL    (0x3002)

#define CPLD_CSR_ID_ADDR                  (0x0)
#define CPLD_CSR_VERSION_ADDR             (0x4)
#define CPLD_CSR_CONTROL_ADDR             (0x8)
#define CPLD_CSR_IRQ_STATUS_ADDR          (0x10)
#define CPLD_CSR_IRQ_MASK_ADDR            (0x14)
#define CPLD_CSR_MUTEX_ADDR               (0x18)
#define CPLD_CSR_REQ_FIFO_STATUS_ADDR     (0x40)
#define CPLD_CSR_RES_FIFO_STATUS_ADDR     (0x44)
#define CPLD_MAX_FIFO_AVAILABLE           (192)
#define CPLD_MAX_HEADER_PAYLOAD_BYTES     (248)

// Commands specific to the FLASH device being accessed
#define FLASH_STATUS_READ_ADDR            (0x555*2)
#define FLASH_STATUS_READ_DATA            (0x70)
#define FLASH_UNLOCK_ADDR_0               (0x555*2)
#define FLASH_UNLOCK_DATA_0               (0xAA)
#define FLASH_UNLOCK_ADDR_1               (0x2AA*2)
#define FLASH_UNLOCK_DATA_1               (0x55)
#define FLASH_ID_ENTRY_ADDR               (0x555*2)
#define FLASH_ID_ENTRY_DATA               (0x90)
#define FLASH_ID_EXIT_ADDR                (0xAA*2)
#define FLASH_ID_EXIT_DATA                (0xF0)

#define FLASH_ID_MODE_MANUFAC_ADDR        (0x0*2)
#define FLASH_ID_MODE_DEVICE_ID_ADDR      (0x1*2)
#define FLASH_ID_EXPECTED_MANUFAC         (0x1)
#define FLASH_ID_EXPECTED_DEVICE_ID       (0x227E)

// Flash commands to program line buffer
#define FLASH_WRITE_BUF_FILL_CMD          (0x25)
#define FLASH_WRITE_BUF_COMMIT_CMD        (0x29)

// Flash commands to erase sector
#define FLASH_ERASESEC_CMD1_ADDR          (0x555*2)
#define FLASH_ERASESEC_CMD1_DATA          (0x80)
#define FLASH_ERASESEC_CMD2_ADDR          (0x555*2)
#define FLASH_ERASESEC_CMD2_DATA          (0xAA)
#define FLASH_ERASESEC_CMD3_ADDR          (0x2AA*2)
#define FLASH_ERASESEC_CMD3_DATA          (0x55)
#define FLASH_ERASESEC_CMD4_DATA          (0x30)


#define FLASH_LINE_BUFFER_ALIGNMENT_BYTES  (512)
#define FLASH_LINE_BUFFER_LENGTH_WORDS     (256)
#define FLASH_LINE_BUFFER_LENGTH_BYTES     (2*FLASH_LINE_BUFFER_LENGTH_WORDS)

#define FLASH_WORDS_PER_SECTOR            (0x10000)
#define WITHIN_SECTOR_ADDRESS_MASK        (0xFFFF)

#define SUPPORTED_FLASH_PARTITIONS        (2)
#define FLASH_BASE_ADDRESS_LOAD_1_ADDR    ((uint32_t)0x10000)
#define FLASH_BASE_ADDRESS_LOAD_2_ADDR    ((uint32_t)0x1730000)
#define FLASH_GLOBAL_RECORD_BASE_ADDR     (0x0)
#define FLASH_LOAD_1_INFO_ADDR            ((uint32_t)0x100)
#define FLASH_LOAD_2_INFO_ADDR            ((uint32_t)0x200)

#define MAX_WRITE_WAIT_COUNT              30000000  // Around a minute during typical execution.  Plenty of time for Flash to process operations.
#define MAX_READ_WAIT_COUNT               MAX_WRITE_WAIT_COUNT
#define MAX_FLASH_READY_WAIT_COUNT        MAX_WRITE_WAIT_COUNT

// Length in bytes of the hashes we create from the FPGA periphery
#define PERIPH_HASH_LENGTH_BYTES          20
#define EXPECTED_PERIPH_HASH_VERSION      1

#define SUPPORTED_CPLD_MIN_REVISION       (0x3)
#define SUPPORTED_CPLD_MAX_REVISION       (0x4)
#define SUPPORTED_BOARD                   (0x2)


class ACL_PCIE_DEVICE;
class ACL_PCIE_MM_IO_MGR;

class ACL_PCIE_FLASH
{
   public:
      ACL_PCIE_FLASH( WDC_DEVICE_HANDLE dev, ACL_PCIE_MM_IO_MGR *io, ACL_PCIE_DEVICE *pcie );
      ~ACL_PCIE_FLASH();

      int flash_read_contents( uint32_t base_word_address, uint32_t num_words, uint16_t *data );
      int flash_program_rbf( char *rbf, size_t rbf_length_bytes, int partition, const char* dev_name );
      int configure_fpga_from_flash( int partition );
      int check_and_set_boot_record_for_partition( uint8_t partition, uint8_t set_to_boot, uint32_t rbf_length_bytes );
      uint8_t validate_and_set_partition_boot_info( uint16_t *boot_sector, uint32_t base_address, uint32_t boot_data_address, uint32_t rbf_length_bytes );
      uint8_t validate_and_set_boot_record( uint16_t *boot_sector, uint8_t partition );
      void flash_debug_dump_boot_sector( void );
      void dump_boot_loader_status( void );
      int does_programmed_periphery_differ_from_fpga_bin( struct acl_pkg_file *pkg, const char* dev_name );

   private:
      uint32_t cpld_read16( uint8_t func_id, uint8_t dev_id, uint32_t addr, unsigned num_words, uint16_t *data, int verbose=0, int skip_fifo_checks=0 );
      uint32_t cpld_write16( uint8_t f_id, uint8_t d_id, uint32_t addr, unsigned num_words, uint16_t *data, int verbose=0, int wait_for_empty_fifo=1 );
      void flash_erase_sector( uint32_t base_word_address );
      void flash_write_512B_line( uint32_t base_word_address, uint16_t *data );
      void flash_unlock_command( void );
      uint8_t is_flash_ready( void );
      int query_periph_hash_on_device( uint32_t *version, uint8_t *hash_20B, const char* dev_name );
      uint16_t cpld_build_header(uint8_t func_id, uint8_t dev_id, uint8_t opcode, uint32_t byte_addr, unsigned byte_length, uint16_t* data);
      uint8_t cpld_is_response_fifo_empty( void );
      uint8_t cpld_is_request_fifo_empty( void );

      WDC_DEVICE_HANDLE   m_device;
      ACL_PCIE_DEVICE    *m_pcie;
      ACL_PCIE_MM_IO_MGR *m_io;
};

#endif // ACL_PCIE_FLASH_H
