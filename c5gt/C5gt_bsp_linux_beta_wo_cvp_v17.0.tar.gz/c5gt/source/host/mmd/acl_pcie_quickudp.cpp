// (C) 1992-2017 Intel Corporation.                            
// Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words    
// and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.  
// and/or other countries. Other marks and brands may be claimed as the property  
// of others. See Trademarks on intel.com for full list of Intel trademarks or    
// the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera) 
// Your use of Intel Corporation's design tools, logic functions and other        
// software and tools, and its AMPP partner logic functions, and any output       
// files any of the foregoing (including device programming or simulation         
// files), and any associated documentation or information are expressly subject  
// to the terms and conditions of the Altera Program License Subscription         
// Agreement, Intel MegaCore Function License Agreement, or other applicable      
// license agreement, including, without limitation, that your use is for the     
// sole purpose of programming logic devices manufactured by Intel and sold by    
// Intel or its authorized distributors.  Please refer to the applicable          
// agreement for further details.                                                 


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

// common and its own header files
#include "acl_pcie.h"
#include "acl_pcie_mm_io.h"
#include "acl_pcie_quickudp.h"

#if defined(LINUX)
#  include <sys/time.h>
#  include <unistd.h>
#endif   // LINUX

#define DEBUG_MSG(m, ...) 
//#define DEBUG_MSG(m, ...) do { printf( "  [QUICKUDP] " m, ## __VA_ARGS__); fflush(stdout); } while (0)

#define DUMP_UDP(A) do { printf(" "#A " = 0x%x\n" , read( A ) ); \
  } while(0)


ACL_PCIE_QUICKUDP::ACL_PCIE_QUICKUDP( ACL_PCIE_MM_IO_DEVICE *io )
{
  m_io = io;
}

ACL_PCIE_QUICKUDP::~ACL_PCIE_QUICKUDP()
{
}

void ACL_PCIE_QUICKUDP::write (uintptr_t offset, UINT32 val) {
  DEBUG_MSG("Writing %x to offset %" PRIxPTR "\n",val, offset);
  m_io->write32( offset * 4, val);
}

UINT32 ACL_PCIE_QUICKUDP::read (uintptr_t offset) {
  UINT32 val;
  m_io->read32( offset * 4, &val);
  DEBUG_MSG("Read %x from offset %" PRIxPTR "\n",val, offset);
  return val;
}

bool ACL_PCIE_QUICKUDP::read_wait (uintptr_t offset, UINT32 val, UINT32 mask) {
  static const int TIMEOUT = 1000; // in ms
  static const int INTERVAL = 50; // in ms
  int retries = 0;

  while ( retries ++ < TIMEOUT/INTERVAL ) {
    if ( (mask & (val ^ read( offset ) )) == 0 )
      return true;

#if defined(WINDOWS)
           Sleep( INTERVAL );
#endif   // WINDOWS
#if defined(LINUX)
           usleep(INTERVAL*1000);
#endif   // LINUX
  }
  return false;
}

void ACL_PCIE_QUICKUDP::dump_status()
{

   DUMP_UDP( UDP_MAC_LOW_ADDR );
   DUMP_UDP( UDP_MAC_HIGH_ADDR );

   DUMP_UDP( UDP_IPV4_ADDR_ADDR );
   DUMP_UDP( UDP_IPV4_MASK_ADDR );
   DUMP_UDP( UDP_ARP_SERVER_DISABLE_ADDR );

   DUMP_UDP( UDP_TX_SESSION_ID_ADDR );
   DUMP_UDP( UDP_TX_CMD_RET_UDP_STATUS_ADDR );
   DUMP_UDP( UDP_RX_SESSION_ID_ADDR );
   DUMP_UDP( UDP_RX_CMD_RET_UDP_STATUS_ADDR );

   DUMP_UDP( UDP_MTU_ADDR );
   DUMP_UDP( UDP_RX_MAX_PKT_CNT_RX_MAX_SESSIONS_ADDR );
   DUMP_UDP( UDP_TX_MAX_PKT_CNT_TX_MAX_SESSIONS_ADDR );
   DUMP_UDP( UDP_MAC_RX_PKT_CNT_ADDR );
   DUMP_UDP( UDP_MAC_RX_CRC_ERROR_CNT_ADDR );
   DUMP_UDP( UDP_MAC_TX_PKT_CNT_ADDR );

   /* Session specific
   DUMP_UDP( UDP_RX_SESSION_ID_ADDR );
   DUMP_UDP( UDP_RX_CMD_EXE_PAGE_RDY_ADDR );
   DUMP_UDP( UDP_RX_CMD_ADDR );
   DUMP_UDP( UDP_RX_CMD_RET_UDP_STATUS_ADDR );
   DUMP_UDP( UDP_RX_LISTEN_UDP_PORT_ADDR );
   DUMP_UDP( UDP_RX_LISTEN_IPV4_MCAST_GROUP_ADDR );
   DUMP_UDP( UDP_RX_PKT_CNT_ADDR );
   DUMP_UDP( UDP_RX_BYTE_CNT_ADDR );
   DUMP_UDP( UDP_RX_DROP_CNT_ADDR );
   DUMP_UDP( UDP_RX_ERROR_CNT_ADDR );
   DUMP_UDP( UDP_RX_IP_ID_ERROR_CNT_ADDR );
   DUMP_UDP( UDP_TX_SESSION_ID_ADDR );
   DUMP_UDP( UDP_TX_CMD_EXE_PAGE_RDY_ADDR );
   DUMP_UDP( UDP_TX_CMD_ADDR );
   DUMP_UDP( UDP_TX_CMD_RET_UDP_STATUS_ADDR );
   DUMP_UDP( UDP_TX_SRC_DEST_UDP_PORT_ADDR );
   DUMP_UDP( UDP_TX_DST_IPV4_ADDR_ADDR );
   DUMP_UDP( UDP_TX_PKT_CNT_ADDR );
   DUMP_UDP( UDP_TX_BYTE_CNT_ADDR );
   DUMP_UDP( UDP_TX_ERROR_CNT_ADDR
   */

}

void ACL_PCIE_QUICKUDP::change_rx_session(int sid)
{
  write(UDP_RX_SESSION_ID_ADDR, sid);
  read_wait( UDP_RX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x01);
}

void ACL_PCIE_QUICKUDP::change_tx_session(int sid)
{
  write(UDP_TX_SESSION_ID_ADDR, sid);
  read_wait( UDP_TX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x01);
}

bool ACL_PCIE_QUICKUDP::issue_rx_session_cmd(UDP_CMD cmd, int port)
{
  if ( !read_wait( UDP_RX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x0f))
    return false;
  write(UDP_RX_CMD_ADDR,                     (UINT32) cmd );
  write(UDP_RX_LISTEN_UDP_PORT_ADDR,         (UINT32) port );
  write(UDP_RX_LISTEN_IPV4_MCAST_GROUP_ADDR, (UINT32) 0 );
  write( UDP_RX_CMD_EXE_PAGE_RDY_ADDR,       (UINT32) (0x01 << 8));
  return read_wait( UDP_RX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x0f);
}

bool ACL_PCIE_QUICKUDP::issue_tx_session_cmd(UDP_CMD cmd, int src_port, int dst_port, int dst_ip)
{
  if ( !read_wait( UDP_TX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x0f))
    return false;
  write(UDP_TX_CMD_ADDR,                     (UINT32) cmd );
  write(UDP_TX_SRC_DEST_UDP_PORT_ADDR,       (UINT32) (src_port << 16) | (dst_port & 0xffff) );
  write(UDP_TX_DST_IPV4_ADDR_ADDR,           (UINT32) dst_ip );
  write(UDP_TX_CMD_EXE_PAGE_RDY_ADDR,        (UINT32) (0x01 << 8));
  return read_wait( UDP_TX_CMD_EXE_PAGE_RDY_ADDR, 0x01, 0x0f);
}

bool ACL_PCIE_QUICKUDP::configure(
    UINT32 mac_lo,
    UINT32 mac_hi,
    UINT32 ip,
    UINT32 ip_mask)
{

  write(UDP_MAC_LOW_ADDR,                    (UINT32) mac_lo );
  write(UDP_MAC_HIGH_ADDR,                   (UINT32) mac_hi );
  write(UDP_IPV4_ADDR_ADDR,                  (UINT32) ip     );
  write(UDP_IPV4_MASK_ADDR,                  (UINT32) ip_mask);
  write(UDP_ARP_CLIENT_TIMEOUT_MS_ADDR,      (UINT32) 0x100  );

  return true;
}

bool ACL_PCIE_QUICKUDP::open_session( int id,
    int    rx_port,
    int    tx_src_port,
    int    tx_dst_port,
    UINT32 tx_dst_ip
    )
{
  bool ok = true;

  change_rx_session(id);
  ok &= issue_rx_session_cmd(UDP_CMD_OPEN, rx_port);

  change_tx_session(id);
  ok &= issue_tx_session_cmd(UDP_CMD_CLOSE, tx_src_port, tx_dst_port, tx_dst_ip);
  if (ok)
    ok &= read_wait( UDP_TX_CMD_RET_UDP_STATUS_ADDR , 0x00, 0x01);
  if (ok)
    ok &= issue_tx_session_cmd(UDP_CMD_OPEN, tx_src_port, tx_dst_port, tx_dst_ip);
  if (ok)
    ok &= read_wait( UDP_TX_CMD_RET_UDP_STATUS_ADDR , 0x001, 0x01f);
  return ok;
}

#undef DUMP_UDP
