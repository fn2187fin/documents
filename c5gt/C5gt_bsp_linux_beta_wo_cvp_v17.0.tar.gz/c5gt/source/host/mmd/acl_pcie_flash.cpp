// (C) 1992-2017 Intel Corporation.                            
// Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words    
// and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.  
// and/or other countries. Other marks and brands may be claimed as the property  
// of others. See Trademarks on intel.com for full list of Intel trademarks or    
// the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera) 
// Your use of Intel Corporation's design tools, logic functions and other        
// software and tools, and its AMPP partner logic functions, and any output       
// files any of the foregoing (including device programming or simulation         
// files), and any associated documentation or information are expressly subject  
// to the terms and conditions of the Altera Program License Subscription         
// Agreement, Intel MegaCore Function License Agreement, or other applicable      
// license agreement, including, without limitation, that your use is for the     
// sole purpose of programming logic devices manufactured by Intel and sold by    
// Intel or its authorized distributors.  Please refer to the applicable          
// agreement for further details.                                                 


/* ===- acl_pcie_flash.cpp  ------------------------------------------- C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file implements routines to reprogram the FPGA configuration Flash.        */
/* Related declarations are in acl_pcie_flash.h.                                   */
/* The functionality implented here is board specific, and depends on the          */
/* interface IP and communication protocol used to access Flash, plus the          */
/* command protocal of the Flash device itself.  This file must be                 */
/* customized when supporting a new board.                                         */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */

/* Common and its own header files */
#include "acl_pcie.h"
#include "acl_pcie_flash.h"

/* Other header files inside the MMD driver */
#include "acl_pcie_device.h"
#include "acl_pcie_mm_io.h"
#include "acl_pcie_debug.h"
#include "pkg_editor.h"

/* Standard header files */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

// Used by Linux-only FLASH dump function
#ifdef LINUX
#include <unistd.h>
#endif


// Constructor
ACL_PCIE_FLASH::ACL_PCIE_FLASH( WDC_DEVICE_HANDLE dev, ACL_PCIE_MM_IO_MGR *io, ACL_PCIE_DEVICE *pcie )
{
   m_device = dev;
   assert(m_device != INVALID_DEVICE);
   m_io = io;
   assert(m_io != NULL);
   m_pcie = pcie;
   assert(m_pcie != NULL);
}

// Destructor
ACL_PCIE_FLASH::~ACL_PCIE_FLASH()
{
}


// Write 16-bit values to the CPLD.  Address is a byte addr.
// Returns number of 16-bit words written
uint32_t ACL_PCIE_FLASH::cpld_write16( uint8_t func_id, uint8_t dev_id, uint32_t addr, unsigned num_words, uint16_t *data, int verbose, int wait_for_empty_fifo )
{
  uint16_t header[4];
  unsigned i;

  unsigned byte_length = num_words*2;  // This function is for 16-bit data

  // Build request packet header
  if(cpld_build_header(func_id, dev_id, CPLD_WRITE_OP, addr, byte_length, header) <= 0) return 0;

  if (verbose) ACL_PCIE_DEBUG_MSG("CPLD write (write request) packet:\n");

  // Wait until the request FIFO has emptied
  if ( wait_for_empty_fifo ) {
    unsigned long wait_count=0;
    while( !cpld_is_request_fifo_empty() && wait_count < MAX_WRITE_WAIT_COUNT ) {
      wait_count++;
    }
    assert( wait_count < MAX_WRITE_WAIT_COUNT &&
        "Exceeded write timeout while waiting for CPLD request queue to be empty for write operation" );
  }

  // Send the write request header
  for(i=0; i<4; i++) {
    if (verbose) ACL_PCIE_DEBUG_MSG("\tWrite header[%i] = 0x%04x\n", i, (unsigned int)header[i]);
    m_io->cpld->write16(0, header[i]);
  }

  // Send the data
  for (i=0; i<num_words; i++) {
    if (verbose) ACL_PCIE_DEBUG_MSG("\tdata = 0x%04x\n", (unsigned int)data[i]);
    m_io->cpld->write16(0, data[i]);
  }

  return num_words;
}


// Read 16-bit values from the CPLD.  Address is a byte addr.
// Returns number of 16-bit words read
uint32_t ACL_PCIE_FLASH::cpld_read16( uint8_t func_id, uint8_t dev_id, uint32_t addr, unsigned num_words, uint16_t *data, int verbose, int skip_fifo_checks )
{
  uint16_t header[4];
  unsigned i;

  unsigned byte_length = num_words*2;  // This function is for 16-bit data

  // Build request packet header
  if(cpld_build_header(func_id, dev_id, CPLD_READ_OP, addr, byte_length, header) <= 0) return 0;

  if (verbose) ACL_PCIE_DEBUG_MSG("CPLD write (read request) packet:\n");

  // Wait for the request FIFO to empty
  if (!skip_fifo_checks) {
    unsigned long wait_count=0;
    while( !cpld_is_request_fifo_empty() && wait_count < MAX_READ_WAIT_COUNT ) {
      wait_count++;
    }
    assert( wait_count < MAX_READ_WAIT_COUNT &&
        "Exceeded read timeout while waiting for CPLD request queue to be empty" );
  }

  // Send the read request header
  for(i=0; i<4; i++) {
    if (verbose) ACL_PCIE_DEBUG_MSG("\tRead header[%i] = 0x%04x\n", i, (unsigned int)header[i]);
    m_io->cpld->write16(0, header[i]);
  }

  // Read the read response header from the CPLD
  for(i=0; i<4; i++) {
    if (!skip_fifo_checks) {
      unsigned long wait_count=0;
      while( cpld_is_response_fifo_empty() && wait_count < MAX_READ_WAIT_COUNT ) {
        wait_count++;
      }
      assert( wait_count < MAX_READ_WAIT_COUNT &&
          "Exceeded read timeout while waiting for CPLD response queue to have header data" );
    }

    m_io->cpld->read16(0, &(header[i]));
    if (verbose) ACL_PCIE_DEBUG_MSG("\tRead response header[%i] = 0x%04x\n", i, (unsigned int)header[i]);
  }

  unsigned response_length_bytes = header[0] & (unsigned)0xFF;

  // Ensure that response packet is a read acknoledgement
  uint16_t response_packet_type = (header[0] >> 8) & (unsigned)0x3;
  if ( response_packet_type != CPLD_ACK_OP ) {
    ACL_PCIE_DEBUG_MSG("CPLD read response packet: Not an ack packet.  Aborting.\n");
    ACL_PCIE_DEBUG_MSG("  Packet type = 0x%x, expected = 0x%x\n",
        response_packet_type, CPLD_ACK_OP);
    assert(0 && "Unexpected CPLD response packet type");
  }

  // Check length of data the CPLD wants to returns against our read request
  if ( response_length_bytes != byte_length ) {
    ACL_PCIE_DEBUG_MSG("CPLD read response packet: Unexpected payload size.  Aborting.\n");
    ACL_PCIE_DEBUG_MSG("  Response length = 0x%x, expected length = 0x%x\n",
        response_length_bytes, byte_length);
    assert(0 && "Unexpected CPLD response packet length");
  }

  // Read the response data from the CPLD
  for(i=0; i < num_words; i++) {
    if (!skip_fifo_checks) {
      unsigned long wait_count=0;
      while( cpld_is_response_fifo_empty() && wait_count < MAX_READ_WAIT_COUNT ) {
        wait_count++;
      }
      assert( wait_count < MAX_READ_WAIT_COUNT &&
          "Exceeded read timeout while waiting for CPLD response queue to have header data" );
    }

    m_io->cpld->read16(0, &(data[i]));
    if (verbose) ACL_PCIE_DEBUG_MSG("\tRead response header[%i] = 0x%04x\n", i, (unsigned int)header[i]);
  }

  return num_words;
}


// Query cpld_bridge status - check whether response FIFO is empty
// Returns 0 for false, 1 for true.
uint8_t ACL_PCIE_FLASH::cpld_is_response_fifo_empty( void ) {
  UINT32 rdata32;
  m_io->cpld_bridge_csr->read32(CPLD_CSR_RES_FIFO_STATUS_ADDR, &rdata32);
  return ((rdata32>>0)&0x1);
}


// Query cpld_bridge status - check whether request FIFO is empty
// Returns 0 for false, 1 for true.
uint8_t ACL_PCIE_FLASH::cpld_is_request_fifo_empty( void ) {
  UINT32 rdata32;
  m_io->cpld_bridge_csr->read32(CPLD_CSR_REQ_FIFO_STATUS_ADDR, &rdata32);
  return ((rdata32>>0)&0x1);
}


// Create the 4 word (16-bit words) CPLD packet protocol header.
// Returns 1 on success, 0 on failure.
uint16_t ACL_PCIE_FLASH::cpld_build_header(uint8_t func_id, uint8_t dev_id, uint8_t opcode, uint32_t byte_addr, unsigned byte_length, uint16_t* data) {

  // Enforce max payload in CPLD packet protocol
  if( byte_length > CPLD_MAX_HEADER_PAYLOAD_BYTES ) {
    return 0;
  }

  // Create first header word
  data[0] = (func_id & 0x3F) << 12 |
            (dev_id & 0x3)   << 10 |
            (opcode & 0x3)   <<  8 |
            (byte_length & 0xFF);

  // Add address words to the header
  data[1] = (uint16_t)(byte_addr & 0xFFFF);
  data[2] = (uint16_t)(byte_addr >> 16);
  data[3] = 0x0;

  // Success
  return 1;
}


// Issue unlock command sequence to the Flash.  Required before operations
// other than Flash data read.
void ACL_PCIE_FLASH::flash_unlock_command( void )
{
  uint16_t data16;
  data16 = FLASH_UNLOCK_DATA_0;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_UNLOCK_ADDR_0, 1, &data16) == 1);
  data16 = FLASH_UNLOCK_DATA_1;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_UNLOCK_ADDR_1, 1, &data16) == 1);
}


// Check Flash status register and return state of the "ready" bit.  Should
// be cleared while the device is busy servicing an operation
uint8_t ACL_PCIE_FLASH::is_flash_ready( void )
{
  uint16_t data16;

  data16 = FLASH_STATUS_READ_DATA;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_STATUS_READ_ADDR, 1, &data16) == 1);

  // Address doesn't matter - all map to status read
  assert(cpld_read16( CPLD_ROUTER_TARGET_FLASH, 0, 0, 1, &data16) == 1);

  if (EXTRACT_BIT(data16,7)) return 1;
  else return 0;
}


// Read a region of Flash memory into buffer.  Operates in blocks to avoid
// overflowing max packet size in the CPLD protocol.
// Returns 1 on success, 0 on failure.
int ACL_PCIE_FLASH::flash_read_contents( uint32_t base_word_address, uint32_t num_words, uint16_t *data ) {
  const unsigned words_per_block = 64;
  const unsigned num_whole_blocks = num_words / words_per_block;
  unsigned remaining_words = num_words - (num_whole_blocks * words_per_block);

  for (unsigned block = 0; block<num_whole_blocks; block++) {
    uint32_t words_read = cpld_read16( CPLD_ROUTER_TARGET_FLASH, 0, (base_word_address + block*words_per_block)*2 /* byte address */,
        words_per_block, &(data[block*words_per_block]) );
    if ( words_read != words_per_block ) {
      ACL_PCIE_INFO("Failed to read Flash contents.  Expected %u words, read %u\n", words_per_block, words_read);
      return 0;
    }
  }

  // If partial block at end that we haven't read yet
  if ( remaining_words ) {
    uint32_t words_read = cpld_read16( CPLD_ROUTER_TARGET_FLASH, 0, (base_word_address + num_whole_blocks*words_per_block)*2 /* byte address */,
        remaining_words, &(data[num_whole_blocks * words_per_block]) );
    if ( words_read != remaining_words ) {
      ACL_PCIE_INFO("Failed to read Flash contents (final line).  Expected %u words, read %u\n", remaining_words, words_read);
      return 0;
    }
  }
  return 1;
}


// Issue command sequence to the CPLD that requests an FPGA reprogram
// operation from Flash.
// Returns 0 on success, negative value on failure.
int ACL_PCIE_FLASH::configure_fpga_from_flash( int partition ) {
  ACL_PCIE_DEBUG_MSG("Commanding reprogramming of FPGA from Flash partition %i!\n", partition);

  uint16_t data16;
  // Setup boot loader command in CPLD through "manual boot loader control register".
  // Defines the partition from which to boot.
  data16 = (((partition+1) << 8) & 0xFF00) | (unsigned)0xE1;
  assert(cpld_write16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_MANUAL_BOOT_CONTROL, 1, &data16) == 1);

  // Trigger reprogram sequence through "flash control and soft reset register" on CPLD
  assert(cpld_read16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_FLASH_CONTROL, 1, &data16 ) == 1);
  ACL_PCIE_DEBUG_MSG("Initial control register readback = %04x\n", data16);

  // Issue the reprogram command sequence
  uint16_t buf[2];
  buf[0] = data16 | (unsigned)0x4000;
  buf[1] = data16 & (unsigned)(~0x4000);
  assert(cpld_write16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_FLASH_CONTROL, 1, &(buf[0])) == 1);
  assert(cpld_write16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_FLASH_CONTROL, 1, &(buf[1])) == 1);
  ACL_PCIE_DEBUG_MSG("Sent reprogram command words\n");

  return 0;
}


// The fastest way to write to the Flash is in 512B lines.  An intermediate
// buffer on the Flash is filled with the data, and a command is sent to
// commit the new line to the underlying memory.  The line is filled in
// blocks to avoid exceeding the maximum CPLD protocol packet size.
void ACL_PCIE_FLASH::flash_write_512B_line( uint32_t base_word_address, uint16_t *data ) {
  const unsigned words_to_write = 256;
  const unsigned block_size_words = 64;  // 64 words + header < max packet paylaod size

  const unsigned num_blocks = words_to_write / block_size_words;
  const uint32_t sector_base_address = base_word_address*2;  // The CPLD bridge firmware strips the lsb of address, so *2 to cancel
  uint16_t data16;
  uint32_t wait_count;

  assert( !(base_word_address % FLASH_LINE_BUFFER_LENGTH_WORDS) && "Flash line address not aligned to line length");
  assert( (num_blocks*block_size_words) == words_to_write );

  // Command Flash to expect 256 words for the write buffer
  flash_unlock_command();

  data16 = FLASH_WRITE_BUF_FILL_CMD;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, sector_base_address, 1, &data16) == 1);
  data16 = words_to_write-1;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, sector_base_address, 1, &data16) == 1);

  for ( unsigned block = 0; block < num_blocks; block++ ) {
    // Partially fill buffer on the flash device with this block's portion of the memory line
    assert( cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, sector_base_address + (block * block_size_words)*2,
          block_size_words, &(data[block * block_size_words]) ) == block_size_words);
  }

  // Command Flash to commit this 512B line buffer to the actual memory
  data16 = FLASH_WRITE_BUF_COMMIT_CMD;
  assert( cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, sector_base_address, 1, &data16) == 1);

  wait_count=0;
  while( !is_flash_ready() && wait_count < MAX_FLASH_READY_WAIT_COUNT ) {
    wait_count++;
  }
  assert( wait_count < MAX_FLASH_READY_WAIT_COUNT &&
      "Exceeded write timeout while waiting for Flash to become ready (write 512B line)" );
}


// Erase a sector in the Flash memory.
void ACL_PCIE_FLASH::flash_erase_sector( uint32_t base_word_address ) {
  uint16_t data16;
  uint32_t wait_count;

  flash_unlock_command();
  
  data16 = FLASH_ERASESEC_CMD1_DATA;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ERASESEC_CMD1_ADDR, 1, &data16) == 1);
  data16 = FLASH_ERASESEC_CMD2_DATA;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ERASESEC_CMD2_ADDR, 1, &data16) == 1);
  data16 = FLASH_ERASESEC_CMD3_DATA;
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ERASESEC_CMD3_ADDR, 1, &data16) == 1);

  // Sector to erase as address.  *2 because CPLD bridge expects byte
  // address, not word address
  data16 = FLASH_ERASESEC_CMD4_DATA;   
  assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, base_word_address*2, 1, &data16) == 1);

  wait_count=0;
  // NOTE: Querying the flash for ready status guarantees that the erase
  // command has already passed through all FIFOs and is at the Flash,
  // since both take the same path.
  while( !is_flash_ready() && wait_count < MAX_FLASH_READY_WAIT_COUNT ) {
    wait_count++;
  }
  assert( wait_count < MAX_FLASH_READY_WAIT_COUNT &&
      "Exceeded write timeout while waiting for Flash to become ready (erase sectors)" );
}


// Program a complete RBF to the Flash memory.  The data comes from the aocx->fpga.bin.
// Return 0 on success.  All other values indicate failure.
int ACL_PCIE_FLASH::flash_program_rbf( char *rbf, size_t rbf_length_bytes, int partition, const char* dev_name ) {
  uint16_t readback_buffer_256_word[ 256 ];
  uint32_t base_word_address;
  uint16_t cpld_version;

  assert( partition < SUPPORTED_FLASH_PARTITIONS );  // Only support a fixed number of Flash partitions
  base_word_address = (unsigned)((partition==0) ? FLASH_BASE_ADDRESS_LOAD_1_ADDR : FLASH_BASE_ADDRESS_LOAD_2_ADDR);

  // Verify that base_word_address is sector aligned.  We could support
  // an unaligned base, but don't need to at the moment
  if ( base_word_address & WITHIN_SECTOR_ADDRESS_MASK ) {
    ACL_PCIE_INFO("[%s] Base_word_address of RBF being programmed to Flash device is not sector aligned.  Aborting program operation.\n", dev_name);
    return 1;
  }

  // Verify that we can talk to the CPLD
  assert(cpld_read16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_CPLD_ID, 1, &cpld_version ) == 1);
  ACL_PCIE_ERROR_IF( (
           ((cpld_version >> 8) & 0xFF) != SUPPORTED_BOARD
        || (cpld_version & 0xFF) < SUPPORTED_CPLD_MIN_REVISION
        || (cpld_version & 0xFF) > SUPPORTED_CPLD_MAX_REVISION ), return 1, 
      "[%s] Can't communicate properly with CPLD supporting FPGA.  Version code is %04X\n", dev_name, cpld_version ); 

  // Verify that we can read properly from the status port on the CPLD bridge
  {
    UINT32 rdata32;
    m_io->cpld_bridge_csr->read32(CPLD_CSR_REQ_FIFO_STATUS_ADDR, &rdata32);
    ACL_PCIE_ERROR_IF( ((rdata32>>16)&0xFFF) > CPLD_MAX_FIFO_AVAILABLE, return 1, 
        "[%s] Can't communicate properly with CPLD supporting FPGA (CSR req FIFO status).  Fill level is %u\n", 
        dev_name, ((rdata32>>16)&0xFFF) ); 
    m_io->cpld_bridge_csr->read32(CPLD_CSR_RES_FIFO_STATUS_ADDR, &rdata32);
    ACL_PCIE_ERROR_IF( ((rdata32>>16)&0xFFF) > CPLD_MAX_FIFO_AVAILABLE, return 1, 
        "[%s] Can't communicate properly with CPLD supporting FPGA (CSR res FIFO status).  Fill level is %u\n", 
        dev_name, ((rdata32>>16)&0xFFF) ); 
  }

  // Verify that we can talk to the Flash device itself
  {
    uint16_t rdata16;
    flash_unlock_command();

    // Request ID mode
    rdata16 = FLASH_ID_ENTRY_DATA;
    assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ID_ENTRY_ADDR, 1, &rdata16) == 1);

    assert(cpld_read16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ID_MODE_MANUFAC_ADDR, 1, &rdata16) == 1);
    ACL_PCIE_ERROR_IF( rdata16 != FLASH_ID_EXPECTED_MANUFAC, return 1, 
        "[%s] Can't communicate properly with Flash device.  Expected manufacturer code=%x, read=%x\n",
        dev_name, FLASH_ID_EXPECTED_MANUFAC, rdata16 ); 
    assert(cpld_read16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ID_MODE_DEVICE_ID_ADDR, 1, &rdata16) == 1);
    ACL_PCIE_ERROR_IF( rdata16 != FLASH_ID_EXPECTED_DEVICE_ID, return 1, 
        "[%s] Can't communicate properly with Flash device.  Expected device ID=%x, read=%x\n",
        dev_name, FLASH_ID_EXPECTED_DEVICE_ID, rdata16 ); 

    // Exit FLASH ID mode
    rdata16 = FLASH_ID_EXIT_DATA;
    assert(cpld_write16( CPLD_ROUTER_TARGET_FLASH, 0, FLASH_ID_EXIT_ADDR, 1, &rdata16) == 1);
  }

  // Determine how many sectors we need to erase/program
  unsigned num_words = ((unsigned)rbf_length_bytes + 2 - 1) / 2; // Ceiling div 2
  unsigned num_sectors_to_erase =
    (num_words + FLASH_WORDS_PER_SECTOR - 1) / FLASH_WORDS_PER_SECTOR; // Ceiling
  unsigned num_lines_to_prog =
    (num_words + FLASH_LINE_BUFFER_LENGTH_WORDS - 1) / FLASH_LINE_BUFFER_LENGTH_WORDS; // Ceiling

  ACL_PCIE_DEBUG_MSG("[%s] Programming %u sectors (%u lines) of the Flash at address %x (partition %i)\n",
      dev_name, num_sectors_to_erase, num_lines_to_prog, base_word_address, partition);

  // Erase the sectors
  ACL_PCIE_INFO("[%s]   Erasing Flash sectors...\n", dev_name);
  for( unsigned sector = 0; sector < num_sectors_to_erase; sector++ ) {
    flash_erase_sector( base_word_address + sector * FLASH_WORDS_PER_SECTOR );
  // Display percentage completion in debug stream
    if (!(sector % (num_sectors_to_erase/20))) ACL_PCIE_DEBUG_MSG("    %03.1f%%\n", ((float)sector / num_sectors_to_erase)*100);
  }
  ACL_PCIE_INFO("[%s]    done.\n", dev_name);

  // Program the sectors
  ACL_PCIE_INFO("[%s]   Programming Flash lines...\n", dev_name);
  for( unsigned line = 0; line < num_lines_to_prog; line++ ) {
    // Final line may not be full with valid data.  In that case, make new
    // 512B line to avoid special handling on lines smaller than 512B.
    if (line == num_lines_to_prog-1) {
      char tmp_line[512];
      unsigned start_byte = line*512;
      unsigned num_bytes = (unsigned)rbf_length_bytes - start_byte;
      for (unsigned i=0; i<num_bytes; i++) {
        tmp_line[i] = rbf[ start_byte + i ];
      }
      flash_write_512B_line( base_word_address + line * FLASH_LINE_BUFFER_LENGTH_WORDS, (uint16_t*)tmp_line );
    } else {
      flash_write_512B_line( base_word_address + line * FLASH_LINE_BUFFER_LENGTH_WORDS, &(((uint16_t*)rbf)[line * FLASH_LINE_BUFFER_LENGTH_WORDS]) );
    }
    // Display percentage completion in debug stream
    if (!(line % (num_lines_to_prog/20))) ACL_PCIE_DEBUG_MSG("    %03.1f%%\n", ((float)line / num_lines_to_prog)*100);
  }
  ACL_PCIE_INFO("[%s]    done.\n", dev_name);

  // Read back the Flash content to make sure that it programmed
  // properly.  If not, then we might have exceeded the Flash sector erase
  // limit causing hardware failures.
  // Readback in 512B Flash lines
  ACL_PCIE_INFO("[%s]   Verifying Flash data...\n", dev_name);
  for ( unsigned long byte = 0, line=0; byte < rbf_length_bytes; line++ ) {
    if (!flash_read_contents( base_word_address + (byte/2), FLASH_LINE_BUFFER_LENGTH_WORDS, readback_buffer_256_word )) {
      return 1;
    }
    // Display percentage completion in debug stream
    if (!(line % (num_lines_to_prog/20))) ACL_PCIE_DEBUG_MSG("    %03.1f%%\n", ((float)line / num_lines_to_prog)*100);
    for (unsigned within_line = 0; within_line < FLASH_LINE_BUFFER_LENGTH_BYTES && byte < rbf_length_bytes; within_line++ ) {
      if ( ((char*)readback_buffer_256_word)[ within_line ] != rbf[byte] ) {
        ACL_PCIE_INFO("[%s]   Flash programming: First readback error at byte offset = %lx.  Expected %02x, read %02x\n",
            dev_name, byte, rbf[byte], ((char*)readback_buffer_256_word)[ within_line ]);
        ACL_PCIE_INFO("[%s]     This error may mean that the maximum number of Flash sector erase cycles has been exceeded.\n", dev_name);
        return 1;  // Failure
      }
      byte++;
    }
  }
  ACL_PCIE_INFO("[%s]    done.\n", dev_name);
  ACL_PCIE_DEBUG_MSG("[%s] Successfully verified %u bytes of data from Flash\n", dev_name, (unsigned int)rbf_length_bytes);

  return 0;  // Success
}


// Read Flash boot sector, and dump to the info stream.
void ACL_PCIE_FLASH::flash_debug_dump_boot_sector( void ) {
  uint16_t *boot_sector = NULL;
  boot_sector = (uint16_t*)malloc(sizeof(uint16_t)*FLASH_WORDS_PER_SECTOR);
  assert( boot_sector && "Can't allocate memory to hold boot sector" );
  
  // Read the boot sector from Flash
  if (!flash_read_contents( FLASH_GLOBAL_RECORD_BASE_ADDR, FLASH_WORDS_PER_SECTOR, boot_sector )) {
    ACL_PCIE_INFO("Failed to readback boot sector\n");
    return;
  }

  ACL_PCIE_INFO("\n::   Dumping Flash bootsector (only non-0xFFFF words displayed):\n");
  for (unsigned i=0; i<FLASH_WORDS_PER_SECTOR; i++) {
    if (boot_sector[i] != 0xffff) ACL_PCIE_INFO("::     [%x] = %04x\n", i, boot_sector[i]);
  }
}


// Set the master boot record and the partition boot info records, if not
// already set appropriately.
// partition: The partition to set the boot info on (0 or 1)
// set_to_boot: Flag.  If non-zero, modifies the master boot record to enable
//   booting from "partition"
// Returns 0 on success, 1 on failure.
int ACL_PCIE_FLASH::check_and_set_boot_record_for_partition( uint8_t partition, uint8_t set_to_boot, uint32_t rbf_length_bytes ) {
  uint16_t *boot_sector = NULL;
  uint32_t boot_record_base_address;
  uint8_t modified_boot_sector = 0;

  assert( partition < SUPPORTED_FLASH_PARTITIONS );  // Only support boot partitions 0 and 1

  if (ACL_PCIE_DEBUG) {
    flash_debug_dump_boot_sector();
  }

  boot_record_base_address = (uint32_t)((partition==0) ? FLASH_LOAD_1_INFO_ADDR : FLASH_LOAD_2_INFO_ADDR);

  // First, readback the entire boot sector.  If we need to modify
  // anything, we'll erase the entire sector and rewrite it
  boot_sector = (uint16_t*)malloc(sizeof(uint16_t)*FLASH_WORDS_PER_SECTOR);
  assert( boot_sector && "Can't allocate memory to hold boot sector" );
  
  // Read the boot sector from Flash
  if (!flash_read_contents( FLASH_GLOBAL_RECORD_BASE_ADDR, FLASH_WORDS_PER_SECTOR, boot_sector )) {
    ACL_PCIE_INFO("Failed to read Flash boot sector\n");
    return 1;
  }

  // First, check whether the boot record for the partition of interest
  // contains the data that we expect.
  modified_boot_sector += validate_and_set_partition_boot_info( boot_sector, boot_record_base_address, 
      (uint32_t)((partition==0) ? FLASH_BASE_ADDRESS_LOAD_1_ADDR : FLASH_BASE_ADDRESS_LOAD_2_ADDR),
      rbf_length_bytes );

  if ( set_to_boot ) {
    modified_boot_sector +=  validate_and_set_boot_record( boot_sector, partition );
  }

  if ( modified_boot_sector ) {
    ACL_PCIE_INFO("Updating Flash boot sector...\n");

    // Erase boot sector
    ACL_PCIE_DEBUG_MSG("::   Erasing boot sector...\n");
    flash_erase_sector( FLASH_GLOBAL_RECORD_BASE_ADDR );
    ACL_PCIE_DEBUG_MSG("::   done.\n");

    // Write new boot sector
    unsigned num_lines_to_write = FLASH_WORDS_PER_SECTOR / FLASH_LINE_BUFFER_LENGTH_WORDS;
    ACL_PCIE_DEBUG_MSG("::   Writing boot sector (%u lines)...\n", num_lines_to_write);
    for (unsigned line=0; line < num_lines_to_write; line++) {
      flash_write_512B_line( FLASH_GLOBAL_RECORD_BASE_ADDR + line * FLASH_LINE_BUFFER_LENGTH_WORDS, &(boot_sector[ line * FLASH_LINE_BUFFER_LENGTH_WORDS ]) );
    }
    ACL_PCIE_DEBUG_MSG("::   done.\n");

    if (ACL_PCIE_DEBUG) {
      flash_debug_dump_boot_sector();
    }

    ACL_PCIE_INFO(" done.\n");
  }

  return 0;  // Success
}


// Check the boot info region for a partition, and if the data is wrong then
// update it.  Returns a uint8_t - if non-zero then this function modified
// the boot info, requiring a sector erase and writeback to the Flash device.
uint8_t ACL_PCIE_FLASH::validate_and_set_partition_boot_info( uint16_t *boot_sector, uint32_t base_address, uint32_t boot_data_address, uint32_t rbf_length_bytes ) {
  uint32_t offset = base_address;
  uint16_t expected_word;
  uint8_t modified = 0;

  expected_word = 0x1234;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = boot_data_address >> 16;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = 0x119;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = 0x20;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = 0x00;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = 0xFFFF;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = (rbf_length_bytes & 0xFFFF);  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = ((rbf_length_bytes >> 16) & 0xFFFF);  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }

  if (modified) {
    ACL_PCIE_DEBUG_MSG("Flash: Updated boot_sector boot info to:\n");
    for (unsigned i=0; i<8; i++) {
      ACL_PCIE_DEBUG_MSG("          [Addr=0x%x]=0x%04x\n", base_address+i, boot_sector[base_address+i]);
    }
  }

  return modified;
}

// Check the boot record for a partition record, and if the data is wrong then update it.
// Returns a uint8_t - if non-zero then this function modified the boot info,
// requiring a sector erase and writeback to the Flash device.
uint8_t ACL_PCIE_FLASH::validate_and_set_boot_record( uint16_t *boot_sector, uint8_t partition ) {
  uint32_t offset = FLASH_GLOBAL_RECORD_BASE_ADDR;
  uint16_t expected_word;
  uint8_t modified = 0;

  assert( partition < SUPPORTED_FLASH_PARTITIONS );  // Only support boot partitions 0 and 1

  expected_word = (((partition+1) << 8) & (unsigned)0xFF00) | (unsigned)0xE1;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }
  expected_word = 0xFFFF;  offset++;
  if ( boot_sector[offset] != expected_word ) { boot_sector[offset] = expected_word; modified++; }

  if (modified) {
    ACL_PCIE_DEBUG_MSG("Flash: Updated boot_sector master boot record to:\n");
    for (unsigned i=0; i<2; i++) {
      ACL_PCIE_DEBUG_MSG("          [Addr=0x%x]=0x%04x\n", FLASH_GLOBAL_RECORD_BASE_ADDR+i, boot_sector[FLASH_GLOBAL_RECORD_BASE_ADDR+i]);
    }
  }

  return modified;
}


// Dump CPLD boot loader status info to debug stream.
void ACL_PCIE_FLASH::dump_boot_loader_status( void ) {
  uint16_t data16;

  // Boot loader status
  assert(cpld_read16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_FLASH_STATUS, 1, &data16, 0, 1 /* HACK: skip FIFO checks */ ) == 1);
  ACL_PCIE_DEBUG_MSG("Boot loader status: 0x%04x\n", data16);
  if ( EXTRACT_BIT( data16, 3 )) ACL_PCIE_DEBUG_MSG("    Boot loader ERROR\n");
  if ( EXTRACT_BIT( data16, 2 )) ACL_PCIE_DEBUG_MSG("    Boot loader complete\n");
  if ( EXTRACT_BIT( data16, 1 )) ACL_PCIE_DEBUG_MSG("    Boot loader busy\n");
  if ( EXTRACT_BIT( data16, 0 )) ACL_PCIE_DEBUG_MSG("    Flash ready\n");

  // Boot loader image status
  assert(cpld_read16( CPLD_ROUTER_TARGET_CPLD, 0, CPLD_REGMAP_BOOT_LD_STATUS, 1, &data16, 0, 1 /* HACK: skip FIFO checks */ ) == 1);
  ACL_PCIE_DEBUG_MSG("FPGA A loaded image is: %d\n", data16 & 0xF);
}


// Read from the onchip_ram component of the iface.  Obtain the 32b version
// code at the start of memory, followed by the 20B periphery hash
// currently programmed.  The hash allows us to determine whether a new
// bitstream to be programmed has the same or a different periphery.
// Returns 0 on success, negative on failure.
int ACL_PCIE_FLASH::query_periph_hash_on_device( uint32_t *version, uint8_t *hash_20B, const char* dev_name )
{
  int status = 0;
  uint32_t arr32[6];  // Read back in 32b words (memory width)
  for (unsigned i=0; i<6; i++) {
    status |= m_io->iface_onchip_ram->read32( i*4, &(arr32[i]));
  }
  ACL_PCIE_ERROR_IF(status, return -1, "Failed to read data (periphery hash) from onchip RAM\n");

  *version = arr32[0];

  // Convert 32b data to 8b data.  Do this manually to avoid endianness
  // differences (don't just cast the pointer).
  unsigned out_pos=0;
  for (unsigned i=1; i<6; i++) {
    for (int j=3; j>=0; j--) {
      hash_20B[out_pos++] = ((arr32[i] >> 8*j) & 0xFF);
    }
  }

  ACL_PCIE_DEBUG_MSG(":: [%s] Periphery hash on device: version=%u, hash=", dev_name, *version);
  for (unsigned i=0; i<PERIPH_HASH_LENGTH_BYTES; i++) ACL_PCIE_DEBUG_MSG("%02x", hash_20B[i]);
  ACL_PCIE_DEBUG_MSG("\n");

  return 0;
}


// Lookup table to convert ASCII nibble into binary nibble.
static char convert_ascii_char_to_binary( char ascii ) {
  switch (ascii) {
    case '0': return 0;
    case '1': return 1;
    case '2': return 2;
    case '3': return 3;
    case '4': return 4;
    case '5': return 5;
    case '6': return 6;
    case '7': return 7;
    case '8': return 8;
    case '9': return 9;
    case 'a': return 0xA;
    case 'A': return 0xA;
    case 'b': return 0xB;
    case 'B': return 0xB;
    case 'c': return 0xC;
    case 'C': return 0xC;
    case 'd': return 0xD;
    case 'D': return 0xD;
    case 'e': return 0xE;
    case 'E': return 0xE;
    case 'f': return 0xF;
    case 'F': return 0xF;
  }
  assert(0 && "Unhandled case converting ascii to binary");
  return 0;  // Avoid Windows warning
}

// Local conversion function.  Converts a pair of ASCII hex charactes to a
// single binary byte value.
static unsigned char convert_ascii_hex_byte_to_binary( char *two_ascii_chars ) {
  return ( (convert_ascii_char_to_binary(two_ascii_chars[0]) << 4) & 0xF0) | convert_ascii_char_to_binary(two_ascii_chars[1]);
}

// Read periphery hash from onchip_ram on FPGA, and compare to the hash  in the
// fpga.bin that we're about to program.
// Returns:
//    0 if peripheries are the same
//    1 if peripheries differ
//    -1 on error
int ACL_PCIE_FLASH::does_programmed_periphery_differ_from_fpga_bin( struct acl_pkg_file *pkg, const char* dev_name )
{
  size_t hash_len = 0;
  uint8_t dev_hash[PERIPH_HASH_LENGTH_BYTES];
  uint8_t pkg_hash[PERIPH_HASH_LENGTH_BYTES];
  uint32_t dev_hash_version;

  // Verify that RBF section exists in fpga.bin
  ACL_PCIE_ERROR_IF( !acl_pkg_section_exists( pkg, ACL_PKG_SECTION_PERIPH_HASH, &hash_len ), 
      return -1, "[%s] fpga.bin doesn't contain PERIPH_HASH section.  Can't configure device.\n", dev_name);

  char *fpga_bin_hash = NULL;
  int read_hash_ok = acl_pkg_read_section_transient( pkg, ACL_PKG_SECTION_PERIPH_HASH, &fpga_bin_hash );
  ACL_PCIE_ERROR_IF( !read_hash_ok, 
      return -1, ":: [%s] Failed while reading periphery hash from fpga.bin...\n", dev_name);
  
  // Convert the ASCII hash (from AOCX) to binary
  for (unsigned i=0; i < PERIPH_HASH_LENGTH_BYTES; i++) {
    pkg_hash[i] = convert_ascii_hex_byte_to_binary( &(fpga_bin_hash[i*2]) );
  }

  ACL_PCIE_DEBUG_MSG(":: [%s] Periphery hash in fpga.bin=", dev_name);
  for (unsigned i=0; i<20; i++) ACL_PCIE_DEBUG_MSG("%02x", (unsigned)((unsigned char)pkg_hash[i]));
  ACL_PCIE_DEBUG_MSG("\n");
  
  ACL_PCIE_ERROR_IF( (this->query_periph_hash_on_device( &dev_hash_version, dev_hash, dev_name ) < 0), 
      return -1, ":: [%s] Failed while reading periphery hash from device.\n", dev_name);

  ACL_PCIE_ERROR_IF( dev_hash_version != EXPECTED_PERIPH_HASH_VERSION, 
      return -1, ":: [%s] Periphery hash version on device mismatches.  Saw=%u, expected=%u.\n",
      dev_name, dev_hash_version, EXPECTED_PERIPH_HASH_VERSION);

  // Compare the hashes, byte by byte
  for ( unsigned i=0; i < PERIPH_HASH_LENGTH_BYTES; i++ ) {
    if ( dev_hash[i] != pkg_hash[i] ) {
      ACL_PCIE_DEBUG_MSG(":: [%s] First periphery hash mismatch on byte %u. Device=%02x, fpga.bin=%02x\n",
          dev_name, i, dev_hash[i], pkg_hash[i] );
      return 1;  // Return "periphs differ"
    }
  }

  // No mismatches.  Return "periphs identical"
  return 0;
}

