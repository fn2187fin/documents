#ifndef ACL_PCIE_CONFIG_H
#define ACL_PCIE_CONFIG_H

/* (C) 1992-2017 Intel Corporation.                             */
/* Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words     */
/* and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.   */
/* and/or other countries. Other marks and brands may be claimed as the property   */
/* of others. See Trademarks on intel.com for full list of Intel trademarks or     */
/* the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera)  */
/* Your use of Intel Corporation's design tools, logic functions and other         */
/* software and tools, and its AMPP partner logic functions, and any output        */
/* files any of the foregoing (including device programming or simulation          */
/* files), and any associated documentation or information are expressly subject   */
/* to the terms and conditions of the Altera Program License Subscription          */
/* Agreement, Intel MegaCore Function License Agreement, or other applicable       */
/* license agreement, including, without limitation, that your use is for the      */
/* sole purpose of programming logic devices manufactured by Intel and sold by     */
/* Intel or its authorized distributors.  Please refer to the applicable           */
/* agreement for further details.                                                  */


/* ===- acl_pcie_config.h  -------------------------------------------- C++ -*-=== */
/*                                                                                 */
/*                         Intel(R) OpenCL MMD Driver                                */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */
/*                                                                                 */
/* This file declares the class to handle functions that program the FPGA.         */
/* The actual implementation of the class lives in the acl_pcie_config.cpp,        */
/* so look there for full documentation.                                           */
/*                                                                                 */
/* ===-------------------------------------------------------------------------=== */

#include "acl_pcie_flash.h"

#define PCIE_AER_CAPABILITY_ID                  ((DWORD)0x0001)
#define PCIE_AER_UNCORRECTABLE_STATUS_OFFSET    ((DWORD)0x4)
#define PCIE_AER_UNCORRECTABLE_MASK_OFFSET      ((DWORD)0x8)
#define PCIE_AER_CORRECTABLE_STATUS_OFFSET      ((DWORD)0x10)
#define PCIE_AER_SURPRISE_DOWN_BIT              ((DWORD)(1<<5))

// Second to wait after issuing "config from flash" command to CPLD
// This is the delay between requesting an FPGA reprogram operation, and
// starting to communicate with the newly programmed device.
#define CONFIG_FROM_FLASH_DELAY_SECONDS         10

class ACL_PCIE_CONFIG
{
   public:
      ACL_PCIE_CONFIG(WDC_DEVICE_HANDLE device);
      ~ACL_PCIE_CONFIG();
      
      // Change the core only via PCIe, using an in-memory image of the core.rbf
      // This is supported only for Stratix V and newer devices. 
      // Return 0 on success.
      int program_core_with_CvP_image(int *core_bitstream, size_t core_rbf_len);

      // Program the FPGA using a given SOF file
      // Return 0 on success.
      int program_with_SOF_file(const char *filename);

      // Functions to save/load control registers from PCI Configuration Space
      // Return 0 on success.
      int save_pci_control_regs();
      int load_pci_control_regs();

      // Functions to query the PCI related information 
      // Use NULL as input for the info that you don't care about 
      // Return 0 on success. 
      int query_pcie_info(unsigned int *pcie_gen, unsigned int *pcie_num_lanes, char *pcie_slot_info_str);

      // Program Flash device with a bitstream
      int flash(struct acl_pkg_file *pkg, uint8_t flash_partition, uint8_t make_bootable, const char* dev_name, ACL_PCIE_FLASH *dev_flash);

      // Reprogram FPGA from a partition on the Flash device
      int reload_fpga_from_flash( int partition, const char* dev_name, ACL_PCIE_FLASH *dev_flash );

      // Windows-specific code to control AER, and retrain the link
      int enable_AER_and_retrain_link_windows( int has_aer, DWORD location_of_aer );
      int disable_AER_windows( int *has_aer, DWORD *location_of_aer );

      // Platform agnostic sleep (in seconds)
      void wait_seconds( unsigned seconds );

   private:
#if defined(WINDOWS)
      // Retrain the PCIe link after programming FPGA with SOF file (Windows only)
      // Return 0 on success.
      int  retrain_link            (WD_PCI_SLOT &slot);

      // Helper functions for finding the PCIe related stuff. (Windows only)
      // Return 1 when target is found.
      int  find_upstream_slot      (WD_PCI_SLOT &slot, WD_PCI_SLOT *upstream);
      int  find_capabilities       (WD_PCI_SLOT &slot, DWORD *offset);      
      int  find_extended_capability(WD_PCI_SLOT &slot, UINT16 ex_cap_id_to_find, DWORD *offset);  

      // Helper functions for "program_core_with_CvP_image". (Windows only)
      // These functions are ported from "/linux64/driver/aclpci_cvp.c".
      void          get_mask_and_offset (unsigned char whichBit, unsigned char *bitMask, unsigned char *bitRegOffset);
      unsigned char wait_for_bit        (WDC_DEVICE_HANDLE device, unsigned char whichBit, unsigned char bitValue);      
      unsigned char read_bit            (WDC_DEVICE_HANDLE device, unsigned char whichBit);   
      void          write_bit           (WDC_DEVICE_HANDLE device, unsigned char whichBit, unsigned char bitValue);
      void          CVP_DRV_SetNumClks  (WDC_DEVICE_HANDLE device, unsigned char numClks);
      void          switch_clock        (WDC_DEVICE_HANDLE device);      
      void          prepare_for_pgm_data(WDC_DEVICE_HANDLE device);
      size_t        send_pgm_data       (WDC_DEVICE_HANDLE device, unsigned int *data, size_t numWords);

      static const unsigned int CONFIG_SPACE_SIZE = 0x1000;
      char m_config_space[CONFIG_SPACE_SIZE];
      WD_PCI_SLOT m_slot;
      WD_PCI_SLOT m_upstream;      
#endif   // WINDOWS
      
      WDC_DEVICE_HANDLE   m_device; 
};

#endif // ACL_PCIE_CONFIG_H
