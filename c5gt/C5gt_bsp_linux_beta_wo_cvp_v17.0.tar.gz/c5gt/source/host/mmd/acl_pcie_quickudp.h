#ifndef ACL_PCIE_QUICKUDP_H
#define ACL_PCIE_QUICKUDP_H

/* (C) 1992-2017 Intel Corporation.                             */
/* Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words     */
/* and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.   */
/* and/or other countries. Other marks and brands may be claimed as the property   */
/* of others. See Trademarks on intel.com for full list of Intel trademarks or     */
/* the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera)  */
/* Your use of Intel Corporation's design tools, logic functions and other         */
/* software and tools, and its AMPP partner logic functions, and any output        */
/* files any of the foregoing (including device programming or simulation          */
/* files), and any associated documentation or information are expressly subject   */
/* to the terms and conditions of the Altera Program License Subscription          */
/* Agreement, Intel MegaCore Function License Agreement, or other applicable       */
/* license agreement, including, without limitation, that your use is for the      */
/* sole purpose of programming logic devices manufactured by Intel and sold by     */
/* Intel or its authorized distributors.  Please refer to the applicable           */
/* agreement for further details.                                                  */


enum UDP_CMD
{
  UDP_CMD_CLOSE                                 = 0,
  UDP_CMD_OPEN                                  = 1,
  UDP_CMD_OPEN_MULTICAST                        = 2  // Used only for RX sessions
};

// UDP Global Configuration Space
#define UDP_VERSION_ADDR                        (0x0C00 + 0x0)
#define UDP_MAC_LOW_ADDR                        (0x0C00 + 0x4)
#define UDP_MAC_HIGH_ADDR                       (0x0C00 + 0x5)
#define UDP_ARP_CLIENT_TIMEOUT_MS_ADDR          (0x0C00 + 0xA)
#define UDP_ARP_SERVER_DISABLE_ADDR             (0x0C00 + 0xB)
#define UDP_IPV4_ADDR_ADDR                      (0x0C00 + 0xC)
#define UDP_IPV4_MASK_ADDR                      (0x0C00 + 0xD)
#define UDP_IPV4_GATEWAY_ADDR                   (0x0C00 + 0xE)
#define UDP_ICMP_SERVER_DISABLE_ADDR            (0x0C00 + 0x14)
#define UDP_IGMP_SERVER_DISABLE_ADDR            (0x0C00 + 0x15)
// UDP Counters and Statistics Space
#define UDP_MTU_ADDR                            (0x0C00 + 0x40)
#define UDP_RX_MAX_PKT_CNT_RX_MAX_SESSIONS_ADDR (0x0C00 + 0x41)
#define UDP_TX_MAX_PKT_CNT_TX_MAX_SESSIONS_ADDR (0x0C00 + 0x42)
#define UDP_MAC_RX_PKT_CNT_ADDR                 (0x0C00 + 0x46)
#define UDP_MAC_RX_CRC_ERROR_CNT_ADDR           (0x0C00 + 0x47)
#define UDP_MAC_TX_PKT_CNT_ADDR                 (0x0C00 + 0x48)
// UDP Session Configuration Space
#define UDP_RX_SESSION_ID_ADDR                  (0x0C00 + 0x80)
#define UDP_RX_CMD_EXE_PAGE_RDY_ADDR            (0x0C00 + 0x81)
#define UDP_RX_CMD_ADDR                         (0x0C00 + 0x82)
#define UDP_RX_CMD_RET_UDP_STATUS_ADDR          (0x0C00 + 0x83)
#define UDP_RX_LISTEN_UDP_PORT_ADDR             (0x0C00 + 0x84)
#define UDP_RX_LISTEN_IPV4_MCAST_GROUP_ADDR     (0x0C00 + 0x85)
#define UDP_RX_PKT_CNT_ADDR                     (0x0C00 + 0x88)
#define UDP_RX_BYTE_CNT_ADDR                    (0x0C00 + 0x89)
#define UDP_RX_DROP_CNT_ADDR                    (0x0C00 + 0x8A)
#define UDP_RX_ERROR_CNT_ADDR                   (0x0C00 + 0x8B)
#define UDP_RX_IP_ID_ERROR_CNT_ADDR             (0x0C00 + 0x8C)
// UDP Session Configuration Space
#define UDP_TX_SESSION_ID_ADDR                  (0x0C00 + 0xC0)
#define UDP_TX_CMD_EXE_PAGE_RDY_ADDR            (0x0C00 + 0xC1)
#define UDP_TX_CMD_ADDR                         (0x0C00 + 0xC2)
#define UDP_TX_CMD_RET_UDP_STATUS_ADDR          (0x0C00 + 0xC3)
#define UDP_TX_SRC_DEST_UDP_PORT_ADDR           (0x0C00 + 0xC4)
#define UDP_TX_DST_IPV4_ADDR_ADDR               (0x0C00 + 0xC5)
#define UDP_TX_PKT_CNT_ADDR                     (0x0C00 + 0xC8)
#define UDP_TX_BYTE_CNT_ADDR                    (0x0C00 + 0xC9)
#define UDP_TX_ERROR_CNT_ADDR                   (0x0C00 + 0xCA)



class ACL_PCIE_MM_IO_DEVICE;

class ACL_PCIE_QUICKUDP
{
   public:
      ACL_PCIE_QUICKUDP( ACL_PCIE_MM_IO_DEVICE *io );
      ~ACL_PCIE_QUICKUDP();

      void dump_status();
      bool configure( UINT32 mac_lo, UINT32 mac_hi, UINT32 ip, UINT32 ip_mask);
      bool open_session( int id, int rx_port, int tx_src_port, int tx_dst_port, UINT32 tx_dst_ip);

   private:
      UINT32 read ( uintptr_t offset );
      bool read_wait (uintptr_t offset, UINT32 val, UINT32 mask=0xffffffff);
      void write ( uintptr_t offset, UINT32 value );
      void change_rx_session(int sid);
      void change_tx_session(int sid);
      bool issue_rx_session_cmd(UDP_CMD cmd, int port);
      bool issue_tx_session_cmd(UDP_CMD cmd, int src_port, int dst_port, int dst_ip);

      ACL_PCIE_MM_IO_DEVICE *m_io;
};

#endif // ACL_PCIE_QUICKUDP_H
