// (C) 1992-2017 Intel Corporation.                            
// Intel, the Intel logo, Intel, MegaCore, NIOS II, Quartus and TalkBack words    
// and logos are trademarks of Intel Corporation or its subsidiaries in the U.S.  
// and/or other countries. Other marks and brands may be claimed as the property  
// of others. See Trademarks on intel.com for full list of Intel trademarks or    
// the Trademarks & Brands Names Database (if Intel) or See www.Intel.com/legal (if Altera) 
// Your use of Intel Corporation's design tools, logic functions and other        
// software and tools, and its AMPP partner logic functions, and any output       
// files any of the foregoing (including device programming or simulation         
// files), and any associated documentation or information are expressly subject  
// to the terms and conditions of the Altera Program License Subscription         
// Agreement, Intel MegaCore Function License Agreement, or other applicable      
// license agreement, including, without limitation, that your use is for the     
// sole purpose of programming logic devices manufactured by Intel and sold by    
// Intel or its authorized distributors.  Please refer to the applicable          
// agreement for further details.                                                 


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aocl_mmd.h"


/* return 1 if given filename has given extension */
int filename_has_ext (const char *filename, const char *ext)
{
   size_t ext_len = strlen (ext);  
   return (strcmp (filename + strlen(filename) - ext_len, ext) == 0);
}

int is_fpga_bin( const char* filename)
{
  if (filename_has_ext (filename, ".bin") || 
      filename_has_ext (filename, ".BIN") ) {
    return 1;
  }
  return 0;
}

/* given filename, load its content into memory.
 * Returns file size in file_size_out ptr and ptr to buffer (allocated
 * with malloc() by this function that contains the content of the file.*/
unsigned char *acl_loadFileIntoMemory (const char *in_file, size_t *file_size_out) {

  FILE *f = NULL;
  unsigned char *buf;
  size_t file_size;
  
  // When reading as binary file, no new-line translation is done.
  f = fopen (in_file, "rb");
  if (f == NULL) {
    fprintf (stderr, "Couldn't open file %s for reading\n", in_file);
    return NULL;
  }
  
  // get file size
  fseek (f, 0, SEEK_END);
  file_size = (size_t)ftell (f);
  rewind (f);
  
  // slurp the whole file into allocated buf
  buf = (unsigned char*) malloc (sizeof(char) * file_size);
  *file_size_out = fread (buf, sizeof(char), file_size, f);
  fclose (f);
  
  if (*file_size_out != file_size) {
    fprintf (stderr, "Error reading %s. Read only %lu out of %lu bytes\n", 
                     in_file, *file_size_out, file_size);
    return NULL;
  }
  return buf;
}

int main(int argc, char ** argv){

   int handle;   
   char *device_name = NULL;
   char *filename_from_cmd = NULL;

   unsigned char *binfile = NULL;
   size_t filesize;
   
   if ( argc != 3 ) {
      printf("Error: Invalid number of arguments.\n");
      return 1;
   }

   device_name = argv[1];
   filename_from_cmd = argv[2];
   
   if ( !is_fpga_bin(filename_from_cmd) ) {
      printf("Error: Not passing in an BIN file.\n");
      return 1;
   }

   binfile = acl_loadFileIntoMemory(filename_from_cmd, &filesize);   
   if ( binfile == NULL ) {
      printf("Error: Unable to load file into memory.\n");
      return 1;
   }
   
   handle = aocl_mmd_open(device_name);
   if ( handle == -1 ) {
      printf("Unable to open the device %s.\n", device_name);
      return 1;
   } else if ( handle < -1) {
      printf("The target board is currently not in a usable state.\n");
      // bitwise-not to get the actual handle number
      handle = ~handle;
   }

   // reprogram the device and it will return a new positive handle if succeed   
   printf("Start to program the device %s ...\n", device_name);
   handle = aocl_mmd_reprogram( handle, (void *)binfile, filesize );
   if ( handle <= 0 ){
      printf("Program failed. \n");
      return 1;   
   }
   
   printf("Program succeed. \n");
   aocl_mmd_close(handle);
   return 0;
}
